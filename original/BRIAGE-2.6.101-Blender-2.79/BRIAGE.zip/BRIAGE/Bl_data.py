﻿
# ##### BEGIN LICENSE BLOCK #####
#
# Copyright (C) 2023  'Juju49'(MERLE-RÉMOND Julian)
# see license notes __init__.py
#
# ##### END LICENSE BLOCK #####

SHORT_SHADER_NAME_DIC = {
	"Shadow":'StencilShadow.fx',
	"TrDiff":'TrainBasicObjectDiffuse.fx',
	"TrGlass":'TrainGlass.fx',
	"TrSpec":'TrainBasicObjectSpecular.fx',
	"TrSpecEM":'TrainSpecEnvMask.fx',
	"TrBumpSpec":'TrainBumpSpec.fx',
	"TrBumpSpecEM":'TrainBumpSpecEnvMask.fx',
	"TrGlassWeather":'TrainGlassWeatherEffects.fx',
	"TrLightMap":'TrainLightMapWithDiffuse.fx',
	"TrEnv":'TrainEnv.fx',
	"TrFlora":'TrainFlora.fx',
	"TrVFaceFlora":'TrainViewFacingFlora.fx',
	"TrUpVFaceFlora":'TrainUprightViewFacingFlora.fx',
	"LoftTexDiff":'LoftTexDiff.fx',
	"LoftTexDiffTr":'LoftTexDiffTrans.fx',
	"Skin":'SkinDiffuse.fx',
	"Water":'WaterCubeMap.fx',
	"WaterScenery":'WaterScenery.fx',
	"Sky":'TrainSkyDome.fx'}
	
RESERVED_OBJECT_NAMES = ['_locomotive', '_tender', '_coach', '_vehicle', '_wagon', '_carriage', '_coal', '_fuel_level_', '_freight', '_bulk', \
'_lights_fwdhead', '_lights_revhead', '_lights_fwdtail', '_lights_revtail', '_light_fwdhead', '_light_revhead', '_light_fwdtail', '_light_revtail']
RESERVED_OBJECT_NAMES_NB = ['_door', '_step', '_wh', '_bo', '_panto', '_wiper', '_primarydigits_', '_secondarydigits_'] # Reserved names followed by 1 or 2 digits
RESERVED_OBJECT_NAMES_1NB = [] # Reserved names followed by 1 digit (any keyword in RESERVED_OBJECT_NAMES_1NB must be also in RESERVED_OBJECT_NAMES_NB)

# OLD:: SHADERS_LIST[i][1] = expected number of slots for TS2012 / SHADERS_LIST[i][2] = related number of slots for Blender (excluding shader name slot)
#MODIFS2016: use xml tools to import from TS/dev/shaders:
#MODIFS2016: shader dic.
#SHADERS_LIST['shader_name'][0] == expected number of slots for TS
#SHADERS_LIST['shader_name'][1] == related number of slots for Blender
#SHADERS_LIST['shader_name'][2] == shader description
SHADERS_LIST = {}
SHADERS_ENUM = []

#List of objects created by exporter to destroy when it ends:
exp_duplicates = []

#====================================================================IMPORTS
import bpy # @UnresolvedImport

from bpy.types import Menu, Panel, UIList  # @UnresolvedImport
from bl_ui.properties_texture import TextureButtonsPanel  # @UnresolvedImport
from bl_ui.properties_material import MaterialButtonsPanel  # @UnresolvedImport
from bl_ui.properties_scene import SceneButtonsPanel  # @UnresolvedImport
from math import log

import sys

#====================================================================REPORT HANDLER

#MODIF2016 new reports handler: implemented everywhere
#method ref: bpy.ops.igs_err.damned('EXEC_DEFAULT', type='INFO', message="")
#type (enum set in {"DEBUG", "INFO", "OPERATOR", "PROPERTY", "WARNING", "ERROR", "ERROR_INVALID_INPUT", "ERROR_INVALID_CONTEXT", "ERROR_OUT_OF_MEMORY"}) <<<--- operator self.report(type, msg) like
#INVOKE_DEFAULT for Popup
class Reporter_OT_OhlalalaLa_LaCata(bpy.types.Operator):
	"""mini reporter for igs exporter functions"""
	bl_idname = "igs_err.damned"
	bl_label = "Exporter's messages to user"
	#
	invoked = bpy.props.BoolProperty(default=False)
	type = bpy.props.StringProperty()
	message = bpy.props.StringProperty()
	#
	def execute(self, context):
		"""writes message according to its type to console and log file"""
		if not self.invoked:
			print("BRIAGE:: '" + self.type + "': "+ self.message)
			if sys.stdout is not sys.__stdout__:
				saveout_temp = sys.stdout
				sys.stdout = sys.__stdout__
				#if not self.invoked:
					#if self.type == 'ERROR': self.report({'WARNING'}, self.message)
					#else: self.report({self.type}, self.message)
				print("BRIAGE:: '" + self.type + "': "+ self.message)
				sys.stdout = saveout_temp
		return {'FINISHED'}
	#
	def invoke(self, context, event):
		"""writes message according to its type to console and log file and pops up a window display"""
		print("BRIAGE:: '" + self.type + "': "+ self.message)
		if sys.stdout is not sys.__stdout__:
			saveout_temp = sys.stdout
			sys.stdout = sys.__stdout__
			print("BRIAGE:: '" + self.type + "': "+ self.message)
			sys.stdout = saveout_temp
		message = self.message
		msgwd = message.split()
		msgwd.reverse()
		message2 = ""
		while msgwd > []:
			msg_line = ""
			while (len(msg_line) < 60) and (msgwd > []):
				msg_line += msgwd.pop()
				msg_line += " "
			msg_line += " \n"
			message2 += msg_line
		self.message2 = message2
		wm = context.window_manager
		return wm.invoke_popup(self, width=510, height=210)
	#
	def draw(self, context):
		"""window display layout"""
		if self.type in ['INFO','DEBUG',]: custom_icon = 'INFO'
		elif self.type == 'WARNING': custom_icon = 'ERROR'
		elif self.type in ['ERROR','ERROR_INVALID_INPUT','ERROR_INVALID_CONTEXT','ERROR_OUT_OF_MEMORY']: custom_icon = 'CANCEL'
		elif self.type in ['OPERATOR','PROPERTY']: custom_icon = 'SCRIPT'
		else: custom_icon = None
		row = self.layout
		row.alignment = 'CENTER'
		row.label(">-~-~ IGS Exporter ~-~-<")
		#
		#https://www.blender.org/api/blender_python_api_2_75_3/bpy.utils.previews.html will be dev for Bl_2.79.0 version & upwards with funny pics or something else fun
		#row = layout.row()
		#row.alignement = 'CENTER'
		#row.label("", icon_value=)
		#
		row = self.layout.split(0.25)
		row.label(self.type, icon=custom_icon)
		col = row.column()
		msg = self.message2
		msg = msg.splitlines()
		for line in msg:
			col.label(line)
		#
		row = self.layout.split(0.60)
		row.separator()
		row.operator_context = 'EXEC_DEFAULT'
		row.operator("igs_err.damned", text="OK (or press 'enter')", icon='FILE_TICK').invoked = True


#====================================================================PROPS
	#collections
class KeywordsListItem(bpy.types.PropertyGroup):
	""" Group of custom keyword """
	# http://www.sinestesia.co/tutorials/making-uilists-in-blender/
	name = bpy.props.StringProperty(
		name="keyword",
		description="A keyword for exporter to group objects together. Write full name to exclude",
		default="_newKword")
	prop1 = bpy.props.BoolProperty(
		name="keyword used for export",
		description="enables keyword's processing during next IGS export",
		default=True)

class TextureStringsListItem(bpy.types.PropertyGroup):
	""" Group of custom tex strings """
	# http://www.sinestesia.co/tutorials/making-uilists-in-blender/
	name = bpy.props.StringProperty(
		name="old string",
		description="",
		default="OldString")
	prop1 = bpy.props.StringProperty(
		name="new string",
		description="",
		default="NewString")

class ObjectStringListItem(bpy.types.PropertyGroup):
	""" Group of custom obj strings """
	# http://www.sinestesia.co/tutorials/making-uilists-in-blender/
	name = bpy.props.StringProperty(
		name="old string",
		description="",
		default="OldString")
	prop1 = bpy.props.StringProperty(
		name="new string",
		description="",
		default="NewString")
		
	# Lists manager:
class LISTBUILDER_UL_BODY(UIList):
	def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
		# http://www.sinestesia.co/tutorials/making-uilists-in-blender/
		custom_icon = 'TEXT'
		if self.layout_type in {'DEFAULT', 'COMPACT'}:
			col1 = layout
			col1.prop(item, "name", emboss=False, text="")
			col1.prop(item, "prop1", text="")
		#
		elif self.layout_type in {'GRID'}:
			layout.alignment = 'CENTER'
			layout.label("", icon = custom_icon)

class LISTBUILDER_OT_NewItem(bpy.types.Operator):
	""" Add a new keyword to KeywordsListItem """
	# http://www.sinestesia.co/tutorials/making-uilists-in-blender/
	bl_idname = "listbuilder.new_item"
	bl_label = "Add an item"
	list = bpy.props.IntProperty()
	def execute(self, context):
		list = self.list
		if list == 0:
			f_list = context.scene.IgsOpt.KeywordsListItem.add()
		elif list == 1:
			f_list = context.scene.IgsOpt.texture_string_to_replace.add()
		elif list == 2:
			f_list = context.scene.IgsOpt.object_string_to_replace.add()
		return{'FINISHED'}

class LISTBUILDER_OT_DeleteItem(bpy.types.Operator):
	""" Delete the selected keyword from KeywordsListItem """
	# http://www.sinestesia.co/tutorials/making-uilists-in-blender/
	bl_idname = "listbuilder.delete_item"
	bl_label = "Deletes an item"
	#
	list = bpy.props.IntProperty()
	#
	#@classmethod
	# def poll(self, context):
		# """ Enable if there's something in the list """
		# list = self.list
		# if list == 0:
			# return context.scene.IgsOpt.KeywordsListItem > 0
		# elif list == 1:
			# return context.scene.IgsOpt.texture_string_to_replace > 0
		# else:
			# return False
		# --> marche pas!
	#
	def execute(self, context):
		list = self.list
		if list is 0:
			context.scene.IgsOpt.KeywordsListItem.remove(context.scene.IgsOpt.KeywordsListIndex)
			if context.scene.IgsOpt.KeywordsListIndex > 0:
				context.scene.IgsOpt.KeywordsListIndex -= 1
		elif list is 1:
			context.scene.IgsOpt.texture_string_to_replace.remove(context.scene.IgsOpt.texture_string_to_replace_index)
			if context.scene.IgsOpt.texture_string_to_replace_index > 0:
				context.scene.IgsOpt.texture_string_to_replace_index -= 1
		elif list is 2:
			context.scene.IgsOpt.object_string_to_replace.remove(context.scene.IgsOpt.object_string_to_replace_index)
			if context.scene.IgsOpt.object_string_to_replace_index > 0:
				context.scene.IgsOpt.object_string_to_replace_index -= 1
		return{'FINISHED'}


# Global options:
def potentialMainObj(self, context):
	mainObj_enum_items = sorted(
		[(obj.name, obj.name, '') for obj in list(bpy.context.scene.objects)])
	
	mainObj_enum_items.insert(0, ('actObj', 'active object', ''))
	return mainObj_enum_items

class IGSExporterSettings(bpy.types.PropertyGroup):
	def __init__(self, context):
		self.context = context
	
	FilePath = bpy.props.StringProperty(description="Igs file destination; can be set after pushing EXPORT button too",
		subtype='FILE_PATH')
	use_selection = bpy.props.BoolProperty(name="use selection",
		description="export selected object and their children. active is main object if none is set",
		default=True)
	visible_children = bpy.props.BoolProperty(name="visible children",
		description="export only visible objects' childrens")
	Verbose = bpy.props.BoolProperty(name="Verbose",
		description="extended debug feature; prints a log file")
	
	u_test_mode = bpy.props.BoolProperty(name="Early tests mode",
		description="bypasses securities and generates missing infos /n Made for you to be able to preview your work quicker")
	u_test_mat = bpy.props.StringProperty(name="Standard test material",  #items=potentialTestmat, 
		description="select a standard material for IGS test exports")
	
	target_textures_directory = bpy.props.StringProperty(description="main texture directory relative filepath",
		default="//Textures",
		subtype='FILE_PATH')
	
	texture_string_to_replace = bpy.props.CollectionProperty(type=TextureStringsListItem)
	texture_string_to_replace_index = bpy.props.IntProperty(name="Index for texture_string_to_replace", default=0)
	object_string_to_replace = bpy.props.CollectionProperty(type=ObjectStringListItem)
	object_string_to_replace_index = bpy.props.IntProperty(name="Index for object_string_to_replace", default=0)
	hierarchy_processing = bpy.props.BoolProperty(name="hierarchy processing",
		description="Allows the exporter to change the scene's hierarchy",
		default=True)
	KeywordsListItem = bpy.props.CollectionProperty(type=KeywordsListItem)
	KeywordsListIndex = bpy.props.IntProperty(name="Index for KeywordsListItem", default=0)
	
	center_main_object_N = bpy.props.BoolVectorProperty(name="Main object centering enabled axis",
		description="enables CMO axis")
	center_main_object = bpy.props.FloatVectorProperty(name="Main object center",
		description="re-centers main object origin on this coordinates",
		subtype='XYZ',
		unit='LENGTH',
		size=3)
	s_main_object = bpy.props.EnumProperty(items=potentialMainObj, name="main Object", 
		description="select a main object for IGS export")
	
	process_bones = bpy.props.BoolProperty(name="export skinned geometry",
		description="Export bones and vertex weights /n make sure all IGS objects are skinned!",
		default=False)
	
	remap_to_igf = bpy.props.BoolProperty(name="remap textures' paths",
		description="Remap paths from *.blend file path to *.igs file path / Map paths as if the *.igs file was in the same directory as the *.blend file",
		default=True)

class IAExporterSettings(bpy.types.PropertyGroup):
	FilePath = bpy.props.StringProperty(description="IA file destination",
		subtype='FILE_PATH')
	export_selected_hierarchy = bpy.props.BoolProperty(
		name="Selected hierarchy",
		description="Export children too?",
		default=False)
	relative_export = bpy.props.BoolProperty(
		name="relative export",
		description="Animation taking into account non-exported parents?",
		default=True)
	#
	Verbose = bpy.props.BoolProperty(
		name="Verbose",
		description="Detailed log file.",
		default=False)
	FrameRateMultiplier = bpy.props.IntProperty(name="Frame rate Multiplier",
		description="Raises animation sample rate",
		default=7,
		min=1,
		max=10)
	RemoveLastFrame = bpy.props.BoolProperty(name="Remove last frame",
		description="Remove last frame for smooth animation loops",
		default=True)
	TrimAnimation = bpy.props.BoolProperty(name="Trim animation",
		description="Trim unused time before first keyframe and after last one",
		default=False)
	#
	def __init__(self,
				 context,
				 FilePath):
		self.context = context
		self.FilePath = FilePath

	# Materials options:
	
#prep 2.8 transition
class IgsTex(bpy.types.PropertyGroup):
	texture: bpy.props.PointerProperty(name="Texture", 
		description="Texture pass for TS Material", 
		type=bpy.types.Image)
	uv_layer: bpy.props.StringProperty(name="UV layer", 
		description="UV pass for TS Material")
	
	use_source_tex_file_path: bpy.props.BoolProperty(name="Cancel 'Textures directory' setting",
		 description="disables 'Textures directory' setting on this texture")
	
	
def UpdateShNameVF(self, context):
	if self.shader_name.find("ViewFacing") >= 0:
		self.view_facing = 'AUTO'
	if self.shader_name.find("FacingFlora") >= 0:
		self.mip_lod_bias = -2.0
	if self.shader_name.find("Spec") >= 0:
		self.mip_lod_bias = -1.0
	return None

def ShItems(self, context):
	return SHADERS_ENUM

class IgsMatPropGp(bpy.types.PropertyGroup):
	preview_active = bpy.props.BoolProperty(name="Preview active", 
		default=True)
	
	shader_name_string = bpy.props.StringProperty(name="custom shader name",
		description="custom shader name to use")
	shader_name = bpy.props.EnumProperty(items=ShItems,
		name="shader name",
		description="name of the TS20XX shader to use",
		update=UpdateShNameVF)
	
	textures = bpy.props.CollectionProperty(type=IgsTex)
	
	ambient_color = bpy.props.FloatVectorProperty(name="Ambiant colour",
		description="Ambiant colour used in TS",
		min=0.0,
		max=1.0,
		subtype='COLOR',
		size=4,
		default=(0.0,0.0,0.0,1.0))
	
	diffuse_color = bpy.props.FloatVectorProperty(name="Diffuse colour",
		description="Diffuse colour used in TS",
		min=0.0,
		max=1.0,
		subtype='COLOR',
		size=4,
		default=(1.0,1.0,1.0,1.0))
	
	specular_color = bpy.props.FloatVectorProperty(name="Specular colour",
		description="Specular colour used in TS",
		min=0.0,
		max=1.0,
		subtype='COLOR',
		size=4,
		default=(1.0,1.0,1.0,1.0))
	
	specular_power = bpy.props.FloatProperty(name="Specular power",
		description="Power of specular colour used in TS",
		min=0.0,
		max=8.0, 
		subtype='UNSIGNED',
		default=3.0)
	
	emissive_color = bpy.props.FloatVectorProperty(name="Emissive colour",
		description="Emissive colour used in TS",
		min=0.0,
		max=1.0,
		subtype='COLOR',
		size=4,
		default=(0.0,0.0,0.0,1.0))
	emissive_power = bpy.props.FloatProperty(name="Emissive power",
		description="Power of emissive colour used in TS",
		min=0.0,
		soft_min=0.0,
		soft_max=3.0,
		subtype='FACTOR')
	
	
	uv_param_1 = bpy.props.FloatProperty(name="arg1", description="UV arg1, param for 1rst pass",
		min=0.0, max=64.0)
	uv_param_2 = bpy.props.FloatProperty(name="arg2", description="UV arg2, param for 1rst pass",
		min=0.0)
	uv_param_3 = bpy.props.FloatProperty(name="arg3", description="UV arg3, param for 1rst pass",
		min=0.0, max=8.0)
	uv_param_4 = bpy.props.FloatProperty(name="arg4", description="UV arg4, param for 1rst pass",
		min=0.0)
	uv_param_5 = bpy.props.FloatProperty(name="arg5", description="UV arg5, param for 1rst pass",
		min=0.0)
	uv_param_6 = bpy.props.FloatProperty(name="arg6", description="UV arg6, param for 1rst pass",
		min=0.0)
	uv_param_Hard = bpy.props.BoolProperty(name="Use specular hardness",
		description="use specular hardness as UV arg1 for 1rst pass",
		default=1)
	alpha_test_mode = bpy.props.BoolProperty(name="Transparency",
		description="(AlphaTestMode) renders 1 bit Alpha transparency")
	animate_uv = bpy.props.BoolProperty(name="Animate UVs",
		description="allows use of animated textures")
	num_frames = bpy.props.IntProperty(name="#Frames",
		description="number of frames anim texture has",
		default=1)
	f_p_s = bpy.props.IntProperty(name="FPS",
		description="texture animation speed - set to 0 to use blender scene's anim speed")
	uv_scroll = bpy.props.BoolProperty(name="scroll UVs",
		description="allows scrolling UVs on a texture")
	scroll_u = bpy.props.FloatProperty(name="scroll U",
		description="proportion of the image scrolled horizontally",
		step=10,
		precision=3)
	scroll_v = bpy.props.FloatProperty(name="scroll V",
		description="proportion of the image scrolled vertically",
		step=10,
		precision=3)
	fmItems = [
		("1", "Point", "1", 1),
		("2", "Bilinear", "2", 2),
		("3", "Trilinear", "3", 3),
		("5", "MipMap", "5", 5)]
	filter_mode = bpy.props.EnumProperty(items=fmItems,
		name="FilterMode",
		description="",
		default='3')
	mip_lod_bias = bpy.props.FloatProperty(name="MipLODBias",
		description="",
		soft_min=-2.0,
		soft_max=0.0)
	back_face_cull= bpy.props.BoolProperty(name="BackFaceCull",
		description="enables back face culling on non-fx shaders")
	two_sided = bpy.props.BoolProperty(name="Two sided",
		description="disables back face culling on fx shaders")							 
	vfItems = [
		("NO", "No", "", 0),
		("VF", "ViewFacing", "", 1),
		("UVF", "UprightViewFacing", "", 2),
		("AUTO", "Auto", "use infos in shader's name", 3)]
	view_facing = bpy.props.EnumProperty(items=vfItems,
		name="Viewer Facing Options",
		description="enables viewer facing options for this material",
		default='AUTO')
	vis_mod = bpy.props.IntProperty(name="Visible distance",
		description="max distance the material can be observed from (0 is infinite)",
		min=0)
	zbItems = [
		("0", "None", "0", 0),
		("1", "Normal", "1 - default", 1),
		("2", "Write Only", "2", 2),
		("3", "Test Only", "3 - allows 8bit alpha transparency with some shaders", 3)]
	z_buffer_mode = bpy.props.EnumProperty(items=zbItems,
		name="ZBufferMode",
		description="3 for transparency",
		default='1')
	comment_field = bpy.props.StringProperty(name="comment",
		description="field used for comment driven shader behaviours, look at possible flags")
	unlit = bpy.props.BoolProperty(name="Unlit",
		description="No dynamic lightning applied")
	preDPP = bpy.props.BoolProperty(name="Pre-DPP",
		description="process before Deferred Post-Production effects")


	# Textures options:
	
class IgsTexPropGp(bpy.types.PropertyGroup):
	final_tex_file_path = bpy.props.StringProperty(name="Export texture path",
		description="texture path used on IGS export instead of Blender's one.",
		subtype='FILE_PATH')
	use_source_tex_file_path = bpy.props.BoolProperty(name="Cancel 'Textures directory' setting",
		description="disables 'Textures directory' setting on this texture")


#====================================================================EXPORT OPS
class IGSExporter(bpy.types.Operator):
	"""Export to the IGS model format (.igs) for Railworks"""
	bl_idname = "export_scene.igs"
	bl_label = "Export IGS"
	#
	filepath = bpy.props.StringProperty(description="Igs file destination", subtype='FILE_PATH')
	#
	def __init__(self):
		Config = bpy.context.scene.IgsOpt
		self.filepath2 = Config.FilePath
	#
	def execute(self, context):
		# Append .igs
		Config = bpy.context.scene.IgsOpt
		wm = context.window_manager
		#
		filepath = bpy.path.ensure_ext(self.filepath, ".igs")
		Config.FilePath = filepath
		Config.context = context
		#
		from .IGSE import ExportIGS
		from .Utilityfcts import ProgressReporterHack
		
		with ProgressReporterHack(context) as pgrh:
			error = ExportIGS(Config, pgrh)
		#
		if error is "FINISHED":
			self.report({'INFO'}, "IGS file successfully created")
			return {'FINISHED'}
		else:
			self.report({'ERROR'}, "IGS exporter failed -- Check Blender's system console or logs")
			return {"FINISHED"}
	#
	def invoke(self, context, event):
		#if not self.filepath:
		if self.filepath2:
			self.filepath = bpy.path.ensure_ext(self.filepath2, ".igs")
		else:
			self.filepath = bpy.path.ensure_ext(bpy.data.filepath[-6:], ".igs")
		wm = context.window_manager
		wm.fileselect_add(self)
		return {"RUNNING_MODAL"}

class IAExporter(bpy.types.Operator):
	"""Export to the IA model format (.ia) for Railworks (2.1.0)"""

	bl_idname = "export_scene.ia"
	bl_label = "Export IA"

	filepath = bpy.props.StringProperty(subtype='FILE_PATH')

	def __init__(self):
		Config = bpy.context.scene.IaOpt
		self.filepath2 = Config.FilePath
		
	def execute(self, context):
		# Append .ia
		FilePath = bpy.path.ensure_ext(self.filepath, ".ia")
		#
		Config = bpy.context.scene.IaOpt
		Config.context = context
		Config.FilePath = FilePath
		#
		from .IAE import ExportIA
		from .Utilityfcts import ProgressReporterHack
		
		with ProgressReporterHack(context) as pgrh:
			errors = ExportIA(Config, pgrh)
			
		if 'FINISHED with error' in errors:
			self.report({'ERROR'}, "IA exporter failed -- Check Blender's system console or logs")
		else:
			self.report({'INFO'}, "IA file successfully created")
		return {"FINISHED"}

	def invoke(self, context, event):
		if not self.filepath:
			if self.filepath2:
				self.filepath = bpy.path.ensure_ext(self.filepath2, ".ia")
			else:
				self.filepath = bpy.path.ensure_ext(bpy.data.filepath, ".ia")
		WM = context.window_manager
		WM.fileselect_add(self)
		return {"RUNNING_MODAL"}

	def draw(self, context):
		layout = self.layout
		scn = context.scene.IaOpt
		#
		col = layout.column()
		col.label("export options:")
		col2 = layout.column()
		col2.prop(scn, "Verbose")
		col.separator()
		#
		col = layout.column()
		col.prop(scn, "FrameRateMultiplier")
		col.prop(scn, "RemoveLastFrame")


#====================================================================UTILITY FCTS
def get_TS_Path_From_WinReg():
	import winreg
	import os.path
	TS_path = ""
	def keypathval(path):
		path = path.split("\\")
		main_key = eval(path[0],{},dict(HKEY_LOCAL_MACHINE=winreg.HKEY_LOCAL_MACHINE, HKEY_CURRENT_USER=winreg.HKEY_CURRENT_USER, HKEY_CURRENT_CONFIG=winreg.HKEY_CURRENT_CONFIG))
		with winreg.OpenKey(main_key, path[1], reserved=0, access=winreg.KEY_READ) as key:
			#print("mainkey:", path[0])
			#print("key:", path[1])
			for i in range(2, len(path)-1):
				key = winreg.OpenKey(key, path[i], reserved=0, access=winreg.KEY_READ)
				#print("key:", path[i])
			val_tpl = ("","","")
			index = 0
			while path[len(path)-1] != val_tpl[0]:
				val_tpl = winreg.EnumValue(key, index)
				#print("val tuple:", val_tpl)
				index += 1
		return val_tpl[1]
	
	def vdflibtspathval(vdf_file):
		from . libs import vdf
		lib_f = (vdf.load(vdf_file))["LibraryFolders"]
		for i in range(1, len(lib_f)-2):
			lib_path = lib_f[str(i)]
			yield lib_path
		
	try:
		key_dir = r"HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\RailWorks\Path"
		TS_path = os.path.normpath(keypathval(key_dir))
	except:
		try:
			key_dir = r"HKEY_CURRENT_USER\Software\Valve\Steam\SteamPath"
			steam_path = os.path.normpath(keypathval(key_dir))
			#print("Steam path:", steam_path)
			if os.path.isfile(steam_path + r"\SteamApps\appmanifest_24010.acf"):
				TS_path = steam_path + r"\SteamApps\common\railworks"
			else:
				with open(steam_path + r"\SteamApps\libraryfolders.vdf") as vreg:
					#print("libraryfolders reg at:", steam_path + r"\SteamApps\libraryfolders.vdf")
					for ipath in vdflibtspathval(vreg):
						#print("Steam lib path:", ipath)
						if os.path.isfile(ipath + r"\SteamApps\appmanifest_24010.acf"):
							TS_path = ipath + r"\SteamApps\common\railworks"
							#print("TS found at:", TS_path)
							break
		except OSError as E:
			print("BRIAGE :: TS path not found in Windows' registry -- [WinError n°{0}] \"{1}\"".format(E.errno, E.strerror))
			return ""
		except:
			print("BRIAGE :: TS path not found in Windows' registry -- unknown error")
			return ""
		
	print("BRIAGE :: TS path gotten from Windows' registry")
	return TS_path

def get_shader_names():
	import xml.etree.ElementTree as ET
	def saveS(temp_shader_enum, index=0, temp_shader_list=None):
		temp_shader_enum.append(("custom","\\custom shader\\","use a shader not listed here", index + 1))
		#save results:
		global SHADERS_ENUM
		SHADERS_ENUM = temp_shader_enum
		if temp_shader_list:
			global SHADERS_LIST
			SHADERS_LIST = temp_shader_list
			try:
				bpy.ops.igs_err.damned('INVOKE_DEFAULT',type='INFO', message=" Shader list built!")
			except:
				print("BRIAGE :: Shader list built")
		return	
	
	#retrieve TS path from user prefs:
	
	addon_prefs = bpy.context.user_preferences.addons[__package__].preferences
	temp_shader_enum = []
	
	if (addon_prefs.ts_install_path != ""):
		path = addon_prefs.ts_install_path
		try:
			bpy.path.abspath(path)
		except:
			try:
				bpy.ops.igs_err.damned('INVOKE_DEFAULT',type='WARNING', message=" Cannot retrieve shader list! - Invalid path")
			except:
				print("BRIAGE :: Cannot retrieve shader list! - Invalid path")
			saveS(temp_shader_enum)
			
	else:#retrieve TS path from Windows:
		path = get_TS_Path_From_WinReg()
		if path == "":
			print("BRIAGE :: Cannot retrieve shader list! - No Windows registry entry")
			saveS(temp_shader_enum)
			return
		addon_prefs.ts_install_path = path
	
	#assign data from UI
	print(path)
	shader_path = bpy.path.abspath(path) + '\\dev\\Shaders\\Shaders.xml'
	chars_per_line = addon_prefs.chars_per_line
	
	#read XML in TS data:
	try:
		tree = ET.parse(shader_path)
		root = tree.getroot()
	except:
		try:
			bpy.ops.igs_err.damned('INVOKE_DEFAULT',type='WARNING', message=" Cannot retrieve shader list! - Wrong path")
		except:
			print("BRIAGE :: Cannot retrieve shader list! - Wrong path")
		saveS(temp_shader_enum)
		return
	if root.tag != 'NamedShaders':
		try:
			bpy.ops.igs_err.damned('INVOKE_DEFAULT',type='WARNING', message=" Cannot retrieve shader list! - Wrong file")
		except:
			print("BRIAGE :: Cannot retrieve shader list! - Wrong file")
		saveS(temp_shader_enum)
		return

	#building shader list
	temp_shader_list = {} #dict for processing shaders
	for child in root:
		#put newlines in descriptions every ~50 chars to ease reading in Blender UI
		txt = child[0].text
		if txt is None: txt = "\\ desc unavailable in shader dict \\"
		txtwd = txt.split()
		txtwd.reverse()
		decription = ""
		while txtwd > []:
			desc_line = ""
			while (len(desc_line) < chars_per_line) and (txtwd > []):
				desc_line += txtwd.pop()
				desc_line += " "
			desc_line += " \n"
			decription += desc_line
		#remember slots:
		sNum_Slots = int(child.attrib['numSlots'])
		#dump infos in dict
		temp_shader_list[child.attrib['name']] = [sNum_Slots, sNum_Slots, decription]

	temp_shader_list['TrainGlassWeatherEffects.fx'][1] = 3 #Blender numslot not the same as in MAX for this shader
	#print(temp_shader_list)
	#create enum:
	temp_shader_enum = []
	index = 0
	for k, _ in sorted(temp_shader_list.items()):
		temp_shader_enum.append((k, k, "", index))
		index += 1
	saveS(temp_shader_enum, index, temp_shader_list)
	return

def update_shader_names(self, context):
	get_shader_names()
	return


#====================================================================UI
#OPS
class TxtHlp() : #methods for drop-down help menus from lists
	def execute(self, context):
		return {'FINISHED'}
	#
	title = "//empty//"
	paragraph = []
	#
	def invoke(self, context, event):
		wm = context.window_manager
		return wm.invoke_popup(self, width=200, height=300)
	#
	def draw(self, context):
		col = self.layout.column()
		col.label((self.title+" :"))
		col = col.split(0.1)
		col.label("")
		col2 = col. column()
		for line in self.paragraph:
			col2.label(line)

class TxtHlp_CfToggles(bpy.types.Operator, TxtHlp) : 
	bl_idname = "briage.ddd"  
	bl_label = "Description"  
	bl_options = {"REGISTER"} 
	#
	title = "Comment field toggles"
	paragraph = [ 
	":forceprelit",
	":pointlit",
	":pre-dpp",
	":unfog",
	":animdelay",
	":animmaxframe",
	":fpsfraction",
	":fadedist",
	":noclip",
	":startinvisible",
	":startnocollide",
	":nocompress",
	":forceunder",
	":fullalphasort",
	":occlude",
	":alternode", #alterable node...
	":shatter",
	":objectstick", ]

class TxtHlp_BuildInKwd(bpy.types.Operator, TxtHlp) : 
	bl_idname = "briage.ddb"  
	bl_label = "Description"  
	bl_options = {"REGISTER"} 
	#
	title = "Build-in Keywords"
	paragraph = ["   Object names:"]+RESERVED_OBJECT_NAMES + \
				["   Followed by a number:"]+RESERVED_OBJECT_NAMES_NB

#PANELS
class SCENE_PT_igs(SceneButtonsPanel, Panel):
	"""Igs config panel"""
	bl_idname = "SCENE_PT_igs"
	bl_label = "IGS export config"
	bl_options = {'DEFAULT_CLOSED'}
	# bl_space_type = 'PROPERTIES'
	# bl_region_type = 'WINDOW'
	# bl_context = "scene"
	COMPAT_ENGINES = {'BLENDER_RENDER', 'BLENDER_GAME'}
	#
	# @Classmethod
	# def poll(self, context):
		# return context.scene == True
	#
	def draw_header(self, context):
		self.layout.operator(IGSExporter.bl_idname, text="EXPORT", icon='FILE_TICK')
	
	def draw(self, context):
		layout = self.layout
		scn = context.scene.IgsOpt
		#
		col = layout.column()
		col.label("IGS target filepath:")
		col.prop(scn, "FilePath", text="", icon='FILE')
		col.separator()
		#
		col = layout.column()
		col.label("export options:")
		col2 = layout.split(0.5)
		col1 = col2.column()
		if scn.use_selection:
			col1.prop(scn, "use_selection", text="export selected", icon='RESTRICT_SELECT_OFF')
		else:
			col1.prop(scn, "use_selection", text="export visible", icon='RESTRICT_VIEW_OFF')
		col1.prop(scn, "visible_children")
		col2 = col2.column()
		#col2.prop(scn, "smaller_IGS_file") #mandatory now
		col2.prop(scn, "Verbose")
		col = layout.column()
		col.prop(scn, "hierarchy_processing")
		col = layout.column()
		#col.enabled = False
		col.prop(scn, "process_bones")
		col.separator()
		#
		col = layout.column()
		col.separator()
		col.prop(scn, "s_main_object", text="main object")
		col = layout.column()
		spl = col.row().split(0.7)
		spl.prop(scn, "center_main_object")
		spl.prop(scn, "center_main_object_N", text="activate axis")
		col.separator()
		#
		col = layout.column()
		col.label("Textures path mapping:")
		if scn.remap_to_igf:
			col.prop(scn, "remap_to_igf", text="write from *.IGS destination", icon="FILE_BLANK")
		else:
			col.prop(scn, "remap_to_igf", text="write from *.blend location", icon="FILE_BLEND")
		col.label("Textures directory:")
		col.prop(scn, "target_textures_directory", text="", icon='IMASEL')
		col.label("to change path individually go to texture's tab,")
		col.label("individual parameters overrides the main")
		col.label("texture directory.")
		col.separator()
		#
		col = layout.column()
		box = col.box()
		box.prop(scn, "u_test_mode")
		col_in = box.column()
		col_in.active = scn.u_test_mode
		#col_in.label("Test material:")
		if len(bpy.data.materials):  # @UndefinedVariable
			col_in.label("Standard test material:")
			col_in.prop_search(scn, "u_test_mat", bpy.data, "materials", text="", icon="MATERIAL_DATA")
		else:
			col_in.label("No materials in blend!", icon="MATERIAL_DATA")
		if scn.u_test_mode:
			box.label("UV and material checks are bypassed", icon='RADIO')
		col.label("")
		col.separator()
		#
		# http://www.sinestesia.co/tutorials/making-uilists-in-blender/
		col = layout.column()
		col.label("Texture strings to replace:", icon='TEXTURE_DATA')
		col.template_list("LISTBUILDER_UL_BODY", "old string -> new string", scn, "texture_string_to_replace", scn, "texture_string_to_replace_index" )
		row = col.row(align=True)
		row.operator('listbuilder.new_item', text='NEW', icon='ZOOMIN').list=1
		row.operator('listbuilder.delete_item', text='REMOVE', icon='ZOOMOUT').list=1
		col.separator()
		#
		colg = col.split(0.9)
		colg.label("Custom keywords:", icon='ORTHO')
		colg.operator(TxtHlp_BuildInKwd.bl_idname, text="", icon='QUESTION', emboss=True)
		col.template_list("LISTBUILDER_UL_BODY", "custom keywords", scn, "KeywordsListItem", scn, "KeywordsListIndex" )
		row = col.row(align=True)
		row.operator('listbuilder.new_item', text='NEW', icon='ZOOMIN').list=0
		row.operator('listbuilder.delete_item', text='REMOVE', icon='ZOOMOUT').list=0
		col.separator()
		#
		col.label("Object Name strings to replace: (!!BONES and SNAP POINTS parenting will fail!!)", icon='OBJECT_DATA')
		col.template_list("LISTBUILDER_UL_BODY", "old name string -> new full name", scn, "object_string_to_replace", scn, "object_string_to_replace_index" )
		row = col.row(align=True)
		row.operator('listbuilder.new_item', text='NEW', icon='ZOOMIN').list=2
		row.operator('listbuilder.delete_item', text='REMOVE', icon='ZOOMOUT').list=2
		col.separator()
		#
		layout.operator(IGSExporter.bl_idname, text="EXPORT", icon='FILE_TICK')

class SCENE_PT_ia(SceneButtonsPanel, Panel):
	"""Igs config panel"""
	bl_idname = "SCENE_PT_ia"
	bl_label = "IA export config"
	bl_options = {'DEFAULT_CLOSED'}
	# bl_space_type = 'PROPERTIES'
	# bl_region_type = 'WINDOW'
	# bl_context = "scene"
	COMPAT_ENGINES = {'BLENDER_RENDER', 'BLENDER_GAME'}
	#
	# @Classmethod
	# def poll(self, context):
		# return context.scene == True
	#
	def draw_header(self, context):
		self.layout.operator(IAExporter.bl_idname, text="EXPORT", icon='ANIM')
	
	def draw(self, context):
		layout = self.layout
		scn = context.scene.IaOpt
		scn2 = context.scene.IgsOpt
		#
		col = layout.column()
		col.label("IA target filepath:")
		col.prop(scn, "FilePath", text="", icon='FILE')
		col.separator()
		#
		col = layout.column()
		col.label("export options:")
		col2 = col.split(0.5)
		col1 = col2.column()
		if scn2.use_selection:
			col1.prop(scn2, "use_selection", text="export selected", icon='RESTRICT_SELECT_OFF')
			col1.prop(scn, "export_selected_hierarchy")
		else:
			col1.prop(scn2, "use_selection", text="export visible", icon='RESTRICT_VIEW_OFF')
			col1.label("")
		col1.prop(scn2, "visible_children")
		col1.prop(scn, "relative_export")
		col1.separator()
		col1.prop(scn2, "process_bones")
		col2 = col2.column()
		col2.label("")
		col2.prop(scn, "Verbose")
		col2.separator
		col2.prop(scn, "FrameRateMultiplier")
		col2.prop(scn, "RemoveLastFrame")
		col2.prop(scn, "TrimAnimation")

class MATERIAL_PT_igs(MaterialButtonsPanel, Panel):
	"""igs per material config"""
	bl_idname = "MATERIAL_PT_igs"
	bl_label = "IGS options"
	bl_options = {'DEFAULT_CLOSED'}
	# bl_space_type = 'PROPERTIES'
	# bl_region_type = 'WINDOW'
	# bl_context = "material"
	COMPAT_ENGINES = {'BLENDER_RENDER', 'BLENDER_GAME'}
	#
	# @Classmethod
	# def poll(self, context):
		# return context.material == True
	#
	def draw(self, context):
		layout = self.layout
		mat = context.material.IgsMat
		bmat = context.material
		#
		col = layout.column()
		col.label("Shader name:")
		if len(SHADERS_ENUM) > 1:
			col.prop(mat, "shader_name", text="")
		if len(SHADERS_ENUM) == 1:
			col.prop(mat, "shader_name_string", text="")
			abox = col.box()
			abox = abox.split(0.1)
			abox1 = abox.row()
			abox1.label("", icon='CANCEL')
			abox1.label("", icon='UNLINKED')
			abox = abox.column()
			abox.label("Shaders' list not generated!")
			abox.label("Please enter the path to your TS directory in:")
			abox.label("File>User pref>Add-ons>IGS Model Format (.igs)")
			fxShader = ('.fx' in mat.shader_name_string)	
		elif mat.shader_name == 'custom':
			col.label("	 custom shader name:")
			col.prop(mat, "shader_name_string", text="")
			fxShader = ('.fx' in mat.shader_name_string)
		else:
			col.label("Shader description:")
			col3 = col.split(0.1)
			col3.label("")
			bol = col3.column().box().column()
			try:
				txt = SHADERS_LIST[mat.shader_name][2]
			except:
				bol.label("unavailable")
			else:
				txt = txt.splitlines()
				for line in txt:
					bol.label(line)
				bolr = bol.row()
				bolr.label("")
				bolr.label("slots needed: " + str(SHADERS_LIST[mat.shader_name][1]), icon='TEXTURE')
			fxShader = ('.fx' in mat.shader_name)
		col.separator()
		#
		col = layout.column()
		col2 = col.split()
		col1 = col2.column()
		#
		col1.prop(mat, "emissive_color")
		col1.prop(bmat, "emit")
		col2 = col2.column()
		#
		col2.label("specular power:")
		(col2.box()).label(str(bmat.specular_intensity * 8), icon='AUTO')
		col.separator()
		#
		col = layout.column()
		col.label("Options:")
		box = col.box()
		rob = box.row()
		rob.label("UV Arguments")
		rob.prop(mat, "uv_param_Hard")
		rob = box.row()
		sub = rob.column()
		if mat.uv_param_Hard:
			sub.label(str(((log(max(0.01, bmat.specular_hardness*0.1)) / 3.933784497209659) * 640000).__trunc__()/10000), icon='AUTO')
		else:
			sub.prop(mat, "uv_param_1")
		rob.prop(mat, "uv_param_2")
		rob.prop(mat, "uv_param_3")
		rob = box.row()
		rob.prop(mat, "uv_param_4")
		rob.prop(mat, "uv_param_5")
		rob.prop(mat, "uv_param_6")
		col.separator()
		#
		box = col.box()
		box.label("Animation / UV Special effects:")
		rbox = box.split()
		lbox = rbox.column()
		lbox.active = not fxShader
		lbox.prop(mat, "uv_scroll")
		sub = lbox.split(0.1)
		sub.enabled = mat.uv_scroll
		sub.label("")
		sub = sub.column(align=True)
		sub.prop(mat, "scroll_u", text="u")
		sub.prop(mat, "scroll_v", text="v")
		rbox = rbox.column()
		rbox.prop(mat, "animate_uv")
		sub = rbox.split(0.1)
		sub.enabled = mat.animate_uv
		sub.label("")
		sub = sub.column()
		sub.prop(mat, "num_frames")
		sub.prop(mat, "f_p_s")
		col2 = col.split()
		col1 = col2.column()
		#
		col1.label("transparency settings:")
		col1.prop(mat, "z_buffer_mode")
		col1.prop(mat, "alpha_test_mode")
		col1.separator()
		#
		col1.label("distance related mods:")
		col1.prop(mat, "vis_mod")
		col1.prop(mat, "mip_lod_bias")
		col1.prop(mat, "filter_mode")
		col1.separator()
		#
		col1.label("various:")
		col1.prop(mat, "unlit")
		col1.prop(mat, "preDPP")
		col1.prop(bmat, "use_cast_shadows", text="cast shadows")
		col1.separator()
		#
		col2 = col2.column()
		#
		col2.label("View facing options:")
		col2sub = col2.column()
		# col2sub.enabled = not ('ViewFacing' in mat.shader_name) #not such a good idea finally...
		col2sub.prop(mat, "view_facing", expand=True)
		col2.separator()
		#
		col2.label("Double siding:")
		subcol = col2.column()
		subcol.active = not fxShader
		subcol.prop(mat, "back_face_cull")
		subcol2 = col2.row()
		subcol2.active = fxShader
		subcol2.prop(mat, "two_sided")
		col2.separator()
		#
		col = layout.column()
		col.label("Comment field:")
		colg = col.split(0.1)
		colg.operator(TxtHlp_CfToggles.bl_idname, text="", icon='QUESTION', emboss=True)
		colg.prop(mat, "comment_field", text="")

class TEXTURE_PT_igs(TextureButtonsPanel, Panel):
	"""Igs config panel"""
	bl_idname = "TEXTURE_PT_igs"
	bl_label = "IGS export config"
	bl_options = {'DEFAULT_CLOSED'}
	# bl_space_type = 'PROPERTIES'
	# bl_region_type = 'WINDOW'
	# bl_context = "texture"
	COMPAT_ENGINES = {'BLENDER_RENDER', 'BLENDER_GAME'}
	#
	def draw(self, context):
		layout = self.layout
		col = layout.column()
		#col.label("IGS final texture path:")
		col.prop(bpy.context.texture.IgsTex, "use_source_tex_file_path")
		col1 = col.column()
		col1.enabled = (not bpy.context.texture.IgsTex.use_source_tex_file_path)
		col1.prop(bpy.context.texture.IgsTex, "final_tex_file_path")



class AddOn_Prefs_igs(bpy.types.AddonPreferences):
	bl_idname = __package__
	#
	ts_install_path = bpy.props.StringProperty(name="TS install directory",
		description="TS20XX install path",
		default="",
		update=update_shader_names,
		subtype='FILE_PATH')
	chars_per_line = bpy.props.IntProperty(name="line length for shader descriptions",
		description="number on chars per line in the dercription",
		min=25,
		default=45)
	#
	def draw(self, context):
		layout = self.layout
		layout.prop(self, "ts_install_path")
		layout.prop(self, "chars_per_line")


#MENUS
def menu_func(self, context):
	self.layout.operator(IGSExporter.bl_idname, text="TS20xx IGS (.igs)")
	self.layout.operator(IAExporter.bl_idname, text="TS20xx IA (.ia)")

#====================================================================REGISTER
classes = (
	Reporter_OT_OhlalalaLa_LaCata,
	KeywordsListItem,
	TextureStringsListItem,
	ObjectStringListItem,
	LISTBUILDER_UL_BODY,
	LISTBUILDER_OT_NewItem,
	LISTBUILDER_OT_DeleteItem,
	IGSExporterSettings,
	IAExporterSettings,
	IgsTex,
	IgsMatPropGp,
	IgsTexPropGp,
	IGSExporter,
	IAExporter,
	TxtHlp_CfToggles,
	TxtHlp_BuildInKwd,
	SCENE_PT_igs,
	SCENE_PT_ia,
	MATERIAL_PT_igs,
	TEXTURE_PT_igs,
	AddOn_Prefs_igs)

def register():
	for cls in classes:
		try:
			bpy.utils.register_class(cls)
		except ValueError:
			pass
	
	bpy.types.INFO_MT_file_export.append(menu_func)
	bpy.types.Scene.IgsOpt = bpy.props.PointerProperty(type=IGSExporterSettings,name="IGS Options",
		description="Options for IGS exporter")
	bpy.types.Scene.IaOpt = bpy.props.PointerProperty(type=IAExporterSettings, name="IA Options",
		description="Options for IA exporter")
	bpy.types.Material.IgsMat = bpy.props.PointerProperty(type=IgsMatPropGp,name="IGS properties",
		description="properties for IGS export")
	bpy.types.Texture.IgsTex = bpy.props.PointerProperty(type=IgsTexPropGp,name="IGS Texture Options",
		description="Texture options for IGS exporter")
	#
	get_shader_names()

def unregister():
	bpy.types.INFO_MT_file_export.remove(menu_func)
	
	for cls in classes:
		try:
			bpy.utils.unregister_class(cls)
		except RuntimeError:
			pass
	
	del bpy.types.Scene.IgsOpt
	del bpy.types.Scene.IaOpt
	del bpy.types.Material.IgsMat
	del bpy.types.Texture.IgsTex
	#del bpy.types.AddonPreferences.AddOn_Prefs_igs
