﻿# ##### BEGIN LICENSE BLOCK #####
#
# Copyright (C) 2018  'DOM107', 'Juju49'(MERLE-RÉMOND Julian)
# see license notes __init__.py
#
# ##### END LICENSE BLOCK #####

#====================================================================INFO
__doc__ = """submodule for exporting IGS files:
	mthd: ExportIGS(Config)
	Config is a class containing 'IgsOpt' and 'context = bpy.context'"""

_info = {
	"version" : (2, 5, "021")}

IGSE_VERSION = 'IGSE V' + '.'.join(str(i) for i in _info['version'])

#====================================================================IMPORTS
import bpy
import os

from mathutils import Vector, Matrix  # @UnresolvedImport
from math import radians, ceil, log

from ._datastructs import IGF
from . Utilityfcts import print_pr, center_main_object
from . Groups import make_groups
from . Bl_data import (
	SHORT_SHADER_NAME_DIC,
	SHADERS_ENUM)
from . SceneCheck import checkScene
from . CleanAndProperSceneExport import CleanAndProperSceneExport
from . libs.autosmooth_normals import MeshPlus


#====================================================================GLOBALS
PROFILE_MODE = "dev" in _info['version'][2]

END_OK = 0
END_ERROR = -1
END_WARNING = -2

KEYWORD_OTHER = 0
KEYWORD_CUSTOM = 1

MAX_NAME_WITH_LOD = 31
MAX_NAME_WITHOUT_LOD = 24
SIZE_DISTANCE_DIGITS = 4
	
VNULL3D = Vector((0.0, 0.0, 0.0))

#matrix to transform vectors into TS instance local space
TO_TS_MATRIX = Matrix.Rotation(radians(90), 4, 'X') * Matrix.Scale(-1, 4, Vector((0, 0, 1)))
#====================================================================EXPORT FCTS

#======================================MATERIALS

# Add a texture file name to the textures list
#MODIFS2016: custom texture paths implementation
def add_texture_to_list(textures_list, Config, texture_data): # MAJ_1_4_0b
	"""list[str] * Config * TextureData -> int
	Register a new texture and/or returns its index+1 in texture_list"""
	#MODIFS2016: specific dir and reroute to props
	# error struct ref: bpy.ops.igs_err.damned('EXEC_DEFAULT', type='INFO', message="")
	
	# MODIFS2016 final specific folder
	final_tex_file_path	= texture_data.IgsTex.final_tex_file_path
	f_ext = final_tex_file_path.rfind('.')

	# MODIFS2016 texture path
	texture_file_name = texture_data.image.filepath
	tfn_test = os.path.basename(texture_file_name)
	if tfn_test is not "":
		ext = tfn_test.rfind('.')
		#replaced by a global SceneCheck# if (ext is -1) and (f_ext is -1): #if no other texture path can be assigned
		#replaced by a global SceneCheck# 	return -2
		
		texture_file_name = tfn_test[:ext]
	
	else: #fallback mode if os.path.basename fails to compute correctly
		ext = texture_file_name.rfind('.')
		#replaced by a global SceneCheck# if (ext is -1) and (f_ext is -1): #if no other texture path can be assigned
		#replaced by a global SceneCheck# 	return -2
		
		base = texture_file_name.rfind('\\')
		if base is not -1:
			texture_file_name = texture_file_name[base+1:ext]
	del tfn_test
	
	# Process texture file substitution   # MAJ_1_4_0b #MODIFS2016
	for strings in Config.texture_string_to_replace: 
		if "#" == strings.name[0]: #texture name replace mode
			if strings.name[1:] == texture_file_name:
				texture_file_name = strings.prop1
				
		elif (strings.name in texture_file_name): #string replace mode
			texture_file_name = texture_file_name.replace(strings.name, strings.prop1)

	# =================================================convert texture_file_name to path
	

	
	# Add specific target:
	if texture_data.IgsTex.use_source_tex_file_path:
		ext = (texture_data.image.filepath).rindex('.')
		texture_file_name = texture_data.image.filepath[:ext]
			
	elif f_ext is not -1:
		texture_file_name = final_tex_file_path[:f_ext]
	
	# Add target textures directory:
	elif Config.target_textures_directory is not "":
		texture_file_name = Config.target_textures_directory + "\\" + texture_file_name
		
	else:
		texture_file_name = r"//" + texture_file_name
	
	if (os.path.basename(texture_file_name)).count(".") > 0:
		texture_file_name += ".safe"
	
	#MODIFS2016 Remap paths:
	ref_path = bpy.path.abspath("//")
	if Config.remap_to_igf:
		ref_path = os.path.dirname(bpy.path.abspath(Config.FilePath))
		
		#replaced by a global SceneCheck# try:
	texture_file_name = (bpy.path.relpath(bpy.path.abspath(texture_file_name), ref_path)).lstrip("/")
		#replaced by a global SceneCheck# except ValueError as VE:
		#replaced by a global SceneCheck# 	p_args = (VE.args[0]).split(',')
		#replaced by a global SceneCheck# 	p_texname = bpy.path.basename(texture_file_name)
		#replaced by a global SceneCheck# 	bpy.ops.igs_err.damned('INVOKE_DEFAULT', type='ERROR', message="Final IGS export path {1} .  But textures {0} .  Please, export to the same drive your data are from!  Texture '{2}' not added".format(p_args[0], p_args[1], p_texname))
		#replaced by a global SceneCheck# 	return -1
	#else:
	#	texture_file_name = (bpy.path.relpath(bpy.path.abspath(texture_file_name), ref_path)).lstrip("/")
	
	#DOESN'T WORK with TS because ConvertToGeo checks number of textures references and is
	#unhappy with this little spared size	
	#if not texture_file_name in set(textures_list):
	#	textures_list.append(texture_file_name)
	textures_list.append(texture_file_name)
	#optimisation possible: nombre de clefs complet
	#mais nombre de valeurs optimisé (pointeurs)
	return len(textures_list)

#MODIF2016: new props pointers, TrUberSh.fx implementation, UV scrolling
def add_igs_material(material, Config, textures_list):
	'''Add an igs material description out of a blender material.'''

	material_found = False
	mNumRenderStages = 0
	num_slot = 0
	add_face_tag_description = False
	IGmat = material.IgsMat
	#
	#Material Config:
	mShaderName = IGmat.shader_name
	if mShaderName == 'custom' or len(SHADERS_ENUM) == 1: mShaderName = IGmat.shader_name_string
	#
	mNeverOcclude = 0
	mSortPriority = 0
	#            
	mAlphaTestMode = IGmat.alpha_test_mode
	mZBias = int(ceil(material.offset_z)) # Round to upper integer
	mZBufferMode = int(IGmat.z_buffer_mode)
	mVisMod = IGmat.vis_mod
	mTwoSided = IGmat.two_sided
	mBackfaceCull = IGmat.back_face_cull	
	#
	mAdditiveAlphaStrength = 0#128
	#
	#MODIFS2016: VF enum AUTO opt:
	mViewFacing = IGF.VF_NONE
	if mShaderName.find('ViewFacing') >= 0:
		if mShaderName.find('Upright') >= 0:
			mViewFacing = IGF.VF_UPRIGHT
		else:
			mViewFacing = IGF.VF_FACING
	if IGmat.view_facing != 'AUTO':
		mViewFacing = IGmat['view_facing']
	
	mAmbient = IGF.IGsColour(float(material.ambient), float(material.ambient), float(material.ambient),1.0)
	mDiffuse = IGF.IGsColour(material.diffuse_color[0],material.diffuse_color[1],material.diffuse_color[2],material.diffuse_intensity)
	mSpecular = IGF.IGsColour(material.specular_color[0],material.specular_color[1],material.specular_color[2],1.0)
	mSpecularPower = material.specular_intensity * 8
	mEmissive = IGF.IGsColour(IGmat.emissive_color[0],IGmat.emissive_color[1],IGmat.emissive_color[2],1.0)
	mEmissiveStrength = material.emit
	
	mSurfaceType = b''#NO COLLIDE'
	
	mUseLightGlow = 0
	mUsePulseGlow = 0
	mLightGlowType = b''#HEADLAMP'
	PulseGlowCmTargCol = IGF.IGsColour(0.78,0.78,1.0,1.0)
	
	PulseGlowCmMode = IGF.PG_PULSE
	PulseGlowCmPhase = 0.0
	PulseGlowCmPeriod = 5
	
	PulseGlowCmRptTimeMin = 1.0
	PulseGlowCmRptTimeMax = 5.0
	PulseGlowCmExeTimeMin = 1.0
	PulseGlowCmExeTimeMax = 5.0
	PulseGlowCmActivationTime = 0.0
	
	PulseGlowCmAmplitude = 1
	
	PulseGlowCmSeqMode = b''#TRAFFIC'
	PulseGlowCmVertexModify = 0
	mUnfoggable = 0
	mForce32Bit = 0
	
	mLMCastShadows = 0
	mLMKeepVertexColours = 0
	mLMGenerateShadows = 1
	mLMTexelsPerMetre = 0
	
	mComment = IGmat.comment_field
	mExtraData = IGF.IGDataBlockContainer()
	#MODIFS2016: some toggles...
	if material.use_cast_shadows:
		mLMCastShadows = 1
	if IGmat.preDPP:
		mComment += ' :pre-dpp'
	if IGmat.unlit:
		mLMKeepVertexColours = 1
	#
	#Render Stages:
	IGRenderSmTextureName = []
	IGRenderSmPadding = []
	IGRenderSmUVChannelIndex = []
	IGRenderSmFilterMode = []
	IGRenderSmUVOperation = []
	IGRenderSmUVWrapU = []
	IGRenderSmUVWrapV = []
	IGRenderSmMipLODBias = []
	IGRenderSmAnimateUVs = []
	IGRenderSmNumFrames = []
	IGRenderSmFPS = []
	IGRenderSmScrollUVs = []
	IGRenderSmScrollU = []
	IGRenderSmScrollV = []
	IGRenderSmArguments = []
				
	for num_s, s in enumerate(material.texture_slots):
		#print(" >>> NEW SLOT")
		if material.use_textures[num_s] and s: # Check if slot is enabled and not empty
			#print(" >>> NEW non empty SLOT")
			if (num_slot is 0) and (s.texture.type == 'NONE') : # Check if slot is not none (old shader name)
				#replaced by a global SceneCheck# bpy.ops.igs_err.damned('EXEC_DEFAULT',type='WARNING', message="{:s} in material {:s} using deprecated shader naming feature!".format(s.name, material.name))
				try:
					mShaderName = SHORT_SHADER_NAME_DIC[s.name]
				except KeyError:
					mShaderName = s.name
				continue
			elif num_slot is 0:
				# FilterMode, AnimateUVs, NumFrames, FPS
				mFilterMode = int(IGmat.filter_mode)
				mAnimateUVs = IGmat.animate_uv
				mNumFrames = IGmat.num_frames
				mFPS = IGmat.f_p_s
				#
				#UV scrolling:
				mScrollUVs = IGmat.uv_scroll
				mScrollU = IGmat.scroll_u
				mScrollV = IGmat.scroll_v
				
				if mAnimateUVs: #animated textures
					mAdditiveAlphaStrength = 0
					
					mSurfaceType = b''
					mUseLightGlow = 0
					mUsePulseGlow = 0
					mLightGlowType = b''
					PulseGlowCmTargCol = IGF.IGsColour(0.0,0.0,0.0,0.0)
					
					PulseGlowCmMode = 0
					PulseGlowCmPhase = 0.0
					PulseGlowCmPeriod = 0
					
					PulseGlowCmRptTimeMin = 0.0
					PulseGlowCmRptTimeMax = 0.0
					PulseGlowCmExeTimeMin = 0.0
					PulseGlowCmExeTimeMax = 0.0
					PulseGlowCmActivationTime = 0.0
					
					PulseGlowCmAmplitude = 0
					
					PulseGlowCmSeqMode = b''
					PulseGlowCmVertexModify = 0
					mUnfoggable = 0
					mForce32Bit = 0
					mAmbient = IGF.IGsColour(0.0,0.0,0.0,0.0)
					mEmissive = IGF.IGsColour(IGmat.emissive_color[0],IGmat.emissive_color[1],IGmat.emissive_color[2],0.0)
					
					mLMGenerateShadows = 0
					mLMTexelsPerMetre = 0
				
				#
				#mNumRenderStages = 0
				num_slot += 1
			else:
				mNumRenderStages += 1
				num_slot += 1
			#
			# Material data for the slot
			IGRenderSmTextureName.append(add_texture_to_list(textures_list, Config, s.texture)) #len_texlist saved
			#
			IGRenderSmPadding.append(b'')
			IGRenderSmUVChannelIndex.append(mNumRenderStages)   # MAJ_1_4_0 /  Channel index
			IGRenderSmFilterMode.append(mFilterMode)
			IGRenderSmUVOperation.append(IGF.UV_OP_COPY)
			IGRenderSmUVWrapU.append(IGF.UVWRAP_TILE)
			IGRenderSmUVWrapV.append(IGF.UVWRAP_TILE)
			if mNumRenderStages is 0:
				#MODIF2016: suggestions from prop update, not forced
				mMipLODBias = IGmat.mip_lod_bias
				IGRenderSmMipLODBias.append(mMipLODBias)
				#
				if IGmat.uv_param_Hard:
					# looks better than original param in TS
					args = ( ( (log(max(0.01, material.specular_hardness*0.1)) / log(51.1)) * 640000).__trunc__()/10000 , IGmat.uv_param_2, IGmat.uv_param_3, IGmat.uv_param_4, IGmat.uv_param_5, IGmat.uv_param_6)
				else:
					args = (IGmat.uv_param_1, IGmat.uv_param_2, IGmat.uv_param_3, IGmat.uv_param_4, IGmat.uv_param_5, IGmat.uv_param_6)
					
				bpy.ops.igs_err.damned('EXEC_DEFAULT',type='PROPERTY', message=" UVArguments for material {0}: {1} {2} {3} {4} {5} {6}".format(material.name, args[0], args[1], args[2], args[3], args[4], args[5]))
				IGRenderSmArguments.append((float(args[0]), float(args[1]), float(args[2]), float(args[3]), float(args[4]), float(args[5])))
			#
			elif mNumRenderStages is 1:
				if mShaderName.find('BumpSpecEnv') >= 0:
					IGRenderSmMipLODBias.append(-1.0)
				#elif mShaderName.find('Spec') >= 0: #jan2020 unused
				#	IGRenderSmMipLODBias.append(0.0)
				else:
					IGRenderSmMipLODBias.append(0.0)
			elif ('WeatherEffects' in mShaderName) and mNumRenderStages is 3: #jan2020 got his own line
				IGRenderSmMipLODBias.append(0.0)
			elif mNumRenderStages > 1: #jan2020 correction for palletised materials
				IGRenderSmMipLODBias.append(mMipLODBias)
				
			if mNumRenderStages is not 0:
				IGRenderSmArguments.append((0.0, 0.0, 0.0, 0.0, 0.0, 0.0))
			IGRenderSmAnimateUVs.append(mAnimateUVs)
			IGRenderSmNumFrames.append(mNumFrames)
			if mFPS is 0:
				# Use model setting
				IGRenderSmFPS.append(int(Config.context.scene.render.fps / Config.context.scene.render.fps_base))
			else:
				# FPS was set in configuration file
				IGRenderSmFPS.append(mFPS)
			#UV scrolling:
			IGRenderSmScrollUVs.append(mScrollUVs)
			IGRenderSmScrollU.append(mScrollU)
			IGRenderSmScrollV.append(mScrollV)
			#
			if ('WeatherEffects' in mShaderName) and (num_slot == 1):
				#replaced by a global SceneCheck#name_split = material.name.split('_')
				#replaced by a global SceneCheck#if len(name_split) != 2 or name_split[0] != 'weatherglass' or not name_split[1].isdigit():
				#replaced by a global SceneCheck#	bpy.ops.igs_err.damned('INVOKE_DEFAULT',type='ERROR', message=" With shader name TrainGlassWeatherEffects.fx, material name must be weatherglass_1, weatherglass_2, etc.. ('{:s}' was found)".format(material.name))
				#replaced by a global SceneCheck#	return None, (num_slot), add_face_tag_description
				
				IGRenderSmTextureName.append(add_texture_to_list(textures_list, Config, s.texture))
				
				mNumRenderStages += 1
				num_slot += 1
				
				IGRenderSmPadding.append(b'')
				IGRenderSmUVChannelIndex.append(0)
				IGRenderSmFilterMode.append(3)
				IGRenderSmUVOperation.append(IGF.UV_OP_COPY)
				IGRenderSmUVWrapU.append(IGF.UVWRAP_TILE)
				IGRenderSmUVWrapV.append(IGF.UVWRAP_TILE)
				IGRenderSmMipLODBias.append(-1.0)
				IGRenderSmAnimateUVs.append(0)
				IGRenderSmNumFrames.append(0)
				IGRenderSmFPS.append(int(Config.context.scene.render.fps / Config.context.scene.render.fps_base))
				IGRenderSmScrollUVs.append(0)
				IGRenderSmScrollU.append(0.0)
				IGRenderSmScrollV.append(0.0)
				# Always 0.0 ,...
				IGRenderSmArguments.append((0.0, 0.0, 0.0, 0.0, 0.0, 0.0))
				#print(" >>> mNumRenderStages 2 {:d}".format(mNumRenderStages))
			#MODIF2016: support for TrainUberShader.fx
			elif mShaderName == "TrainUberShader.fx":
				mSurfaceType = b'METAL'
				mUseLightGlow = 1
			#
			material_found = True
		#
	if not material_found:
		textures_list.append("")
		IGRenderSmTextureName.append(len(textures_list))
		IGRenderSmPadding.append(b'')
		IGRenderSmUVChannelIndex.append(0)
		IGRenderSmFilterMode.append(0)
		IGRenderSmUVOperation.append(IGF.UV_OP_COPY)
		IGRenderSmUVWrapU.append(0)
		IGRenderSmUVWrapV.append(0)
		IGRenderSmMipLODBias.append(0.0)
		IGRenderSmAnimateUVs.append(0)
		IGRenderSmNumFrames.append(0)
		IGRenderSmFPS.append(0)
		IGRenderSmScrollUVs.append(0)
		IGRenderSmScrollU.append(0.0)
		IGRenderSmScrollV.append(0.0)
		IGRenderSmArguments.append((0.0, 0.0, 0.0, 0.0, 0.0, 0.0))
		
		#material_found = True
	
	#08/2018 - Jáchym Hurtík fix
	#if ('WeatherEffects' in mShaderName):
	#	num_slot -= 1
	
	#MODIFS2016: Shader dict
	#replaced by a global SceneCheck# if material_found:
		#replaced by a global SceneCheck# if mShaderName in SHADERS_LIST:
		#replaced by a global SceneCheck# 	if (int(SHADERS_LIST[mShaderName][1]) != num_slot):
		#replaced by a global SceneCheck# 		bpy.ops.igs_err.damned('INVOKE_DEFAULT',type='ERROR', message=" Incorrect number of slots for shader name {0} used in material named {1}, {2} texture slots must be set in Blender; {3} found".format(mShaderName, material.name, SHADERS_LIST[mShaderName][1], num_slot))
		#replaced by a global SceneCheck# 		return None, num_slot, add_face_tag_description
	new_material = IGF.IGMaterials(material.name, mShaderName, mNumRenderStages + 1, \
	IGRenderSmTextureName, IGRenderSmPadding, IGRenderSmUVChannelIndex, IGRenderSmFilterMode, IGRenderSmUVOperation, IGRenderSmUVWrapU, \
	IGRenderSmUVWrapV, IGRenderSmMipLODBias, \
	IGRenderSmAnimateUVs, IGRenderSmNumFrames, IGRenderSmFPS, IGRenderSmScrollUVs, IGRenderSmScrollU, IGRenderSmScrollV, IGRenderSmArguments, \
	mNeverOcclude, mSortPriority, mZBias, mAlphaTestMode, mAdditiveAlphaStrength, mZBufferMode, \
	mBackfaceCull, mTwoSided, mViewFacing, mVisMod, mSurfaceType, mUseLightGlow, mUsePulseGlow, mLightGlowType, \
	PulseGlowCmTargCol, PulseGlowCmMode, PulseGlowCmPhase, PulseGlowCmPeriod, PulseGlowCmAmplitude, PulseGlowCmRptTimeMin, \
	PulseGlowCmRptTimeMax, PulseGlowCmExeTimeMin, PulseGlowCmExeTimeMax, PulseGlowCmActivationTime, PulseGlowCmSeqMode, PulseGlowCmVertexModify, \
	mUnfoggable, mForce32Bit, mAmbient, mDiffuse, mEmissive, \
	mEmissiveStrength, mSpecular, mSpecularPower, mLMCastShadows, mLMGenerateShadows, mLMKeepVertexColours, mLMTexelsPerMetre, mComment, mExtraData)

	return new_material, num_slot, add_face_tag_description
	#replaced by a global SceneCheck# else:
	#replaced by a global SceneCheck# 	bpy.ops.igs_err.damned('INVOKE_DEFAULT',type='ERROR', message=" Unknown error happened while trying to return material {0}".format(material.name))
	#replaced by a global SceneCheck# 	return None, (num_slot - 1), add_face_tag_description

def create_materials_igs(Config, IGctn):
	'''Export all materials and make them easily accessible from geometry'''
	
	#sort set into list to put test_mat forward. needed to compute faces and verts
	#efficiently later
	if Config.u_test_mode:
		test_mat = bpy.data.materials[Config.u_test_mat]  # @UndefinedVariable
		if test_mat in IGctn.mat_data_index:
			IGctn.mat_data_index = [test_mat]+[m for m in IGctn.mat_data_index if m != test_mat]
	
	#export materials
	for mat in IGctn.mat_data_index:
		material_IGMaterials, nb_slots, add_face_tag_description_mat = add_igs_material(mat, Config, IGctn.textures_list)
		
		IGctn.add_face_tag_description = add_face_tag_description_mat or IGctn.add_face_tag_description
		
		#build helpers for storage and fast matching respectively 
		IGctn.materials_list.append([material_IGMaterials, nb_slots])
		IGctn.materials_sdict[mat.name] = len(IGctn.materials_list) - 1
	
	IGctn.materials_count = len(IGctn.mat_data_index)


#======================================GEOMETRY

def update_bounding_box(Vmin_bounding_box, Vmax_bounding_box, new_vector):

	m = Vmin_bounding_box
	M = Vmax_bounding_box

	m.x = min(m.x, new_vector.x)
	m.y = min(m.x, new_vector.y)
	m.z = min(m.x, new_vector.z)
	
	M.x = max(M.x, new_vector.x)
	M.y = max(M.x, new_vector.y)
	M.z = max(M.x, new_vector.z)


#MODIF2016: Vertex color, Bone Binding, is_skinned adapt
def process_mesh_geometry(
		obj,
		first_obj_matrix,
        g_transform,
		Vmin_bounding_box, 
		Vmax_bounding_box, 
		bones_list, 
		mat_data_index, 
		materials_list, 
		materials_sdict, 
		object_triangles_list, 
		object_vertices_list, 
		vertices_count, 
		vertices_count_start, 
		triangles_count, 
		Config, 
		mExtraData, 
		object_vertices_params_list,
		remote_is_skinned
		):

	try:
		data = obj.to_mesh(Config.context.scene, True, 'PREVIEW') # Create a Mesh datablock with modifiers applied (Applying modifiers 'preview' settings)
		#print(" >>> preview", obj.name)
	except:
		return END_ERROR
	
	#MODIFS2016: is blender parent an armature?
	is_skinned = False
	if len(obj.vertex_groups) is not 0:
		for mod in obj.modifiers:
			if mod.type == 'ARMATURE' and mod.use_vertex_groups:
				is_skinned = True
				break
	
	#associate available vertex groups with offsets exported earlier for data-matching with bone bindings of verts:
	if is_skinned:
		all_bones_names = {bone.mName : i for i, bone in enumerate(bones_list)}
		all_group_indices = {vGroup.index : all_bones_names[vGroup.name.encode()] for vGroup in obj.vertex_groups if vGroup.name.encode() in all_bones_names}
		
		MAX_EXPORTED_BONES = 4#IGF.MAX_EXPORTED_BONES #it supports up to 8 in IGS but if there are more than 4, vertices are distorted in game...
		gVertexWeightThreshold = IGF.gVertexWeldNormalThreshold
	
	#generate sharp edges from auto_smooth settings then recalc normals
	data_mp = None
	if not data.has_custom_normals:
		data_mp = MeshPlus(data, 
			not data.has_custom_normals,
			False)
	else:
		data.calc_normals_split()
		data.calc_tessface()
	
	# Vertices colour export?
	export_v_col = data.tessface_vertex_colors.active is not None
	
	# Get vertices, UVs from datablock
	dtex = data.tessface_uv_textures
	
	
	# Change of coordinates system
	common_transform = TO_TS_MATRIX * \
        first_obj_matrix.inverted() * \
        g_transform * obj.matrix_world

	common_notransform_rotscale = common_transform.copy()
	common_notransform_rotscale.translation = VNULL3D
	
	u_test_mode = Config.u_test_mode
	data_mat_available = bool(len(data.materials))
	uv_unavailable = not data.tessface_uv_textures
	
	
	
	for face in data.tessfaces:
		face_num = face.index
		#get vertices:
		f_v = face.vertices
		
		#Normals
		face_normal_rot = common_notransform_rotscale * face.normal
		face_normal = IGF.IGsVector4(face_normal_rot.x, face_normal_rot.y, face_normal_rot.z, 1.0)
		f_split_normals = tuple(Vector(n) for n in face.split_normals)
		
		#determine used material for this face
		mat_index = 0 #u-test-mat here!!
		if (not u_test_mode) or ( data_mat_available and (face.material_index is not None) ):
			if u_test_mode:
				#the materials may have been incompatible and hence suppressed. watch out and do this:
				mat_name = data.materials[face.material_index].name
				if mat_name in materials_sdict:
					mat_index = materials_sdict[mat_name]
					
			else:
				assert data_mat_available, "no materials for object '{}'".format(obj.name)
				mat_index = materials_sdict[data.materials[face.material_index].name] 
					
		#IGmat = materials_list[mat_index][0]
		#BLmat = mat_data_index[mat_index]
		f_mat_nb_slots = materials_list[mat_index][1]
		#print(" >>>> f_mat_nb_slots {:d} f_mat.name {:s} face.material_index {:d} ".format(f_mat_nb_slots, f_mat_name, face.material_index))
		
		mat_igs_offset = IGF.HEADER_SIZE + mat_index * IGF.MATERIAL_SIZE
		
		# In a given mesh, a slot may have a specific UV mapping (MAJ_1_4_0)
		f_uv_list = []
		nb_uvMaps = 0
		
		if u_test_mode and uv_unavailable:
			nb_uvMaps = f_mat_nb_slots
			
		else:
			active_uv_layer = dtex[obj.data.uv_textures.active_index].data[face_num].uv
			#print(" >>> UVMaps for obj {}; face n°{}".format(obj.name, face_num))
			for tex_slot in mat_data_index[mat_index].texture_slots: # MAJ_1_4_0
				if (tex_slot is not None) and (tex_slot.use) and (tex_slot.texture.type == 'IMAGE') :
					#print("IMAGE found")
					if (tex_slot.uv_layer in dtex): #name found in UVmaps list
						f_uv_list.append(dtex[tex_slot.uv_layer].data[face_num].uv)
						#print(" >>> added {}".format(tex_slot.uv_layer))
						
					else: # name is "" or name is invalid
						f_uv_list.append(active_uv_layer)
						#print(" >>> added {}".format(data.tessface_uv_textures[0].name))
						
					nb_uvMaps += 1
			
			if b"WeatherEffects" in materials_list[mat_index][0].mShaderName:
				# name is "" or name is invalid
				f_uv_list.append(active_uv_layer)
				#print(" >>> added {} for WeatherEffects".format(data.tessface_uv_textures[0].name))
				nb_uvMaps += 1
				#f_mat_nb_slots += 1
			
			assert (f_mat_nb_slots is nb_uvMaps), "{}: Slots and UVmaps number do not match: {} | {}".format(
				data.materials[face.material_index].name, str(f_mat_nb_slots), str(nb_uvMaps))
		
		# Triangle or quad
		# ----------------
		
		num_subfaces = 1 if len(f_v) is 3 else 2
		for nb in range(num_subfaces):#range(2):
			triangle_vertices_list = []
			triangle_vertices_indices_list = []
			if nb is 0:
				num1, num2, num3 = 0, 1, 2
				
				if num_subfaces is 2: #MODIFS2016: Quad: hide diagonal edge, hidden edges always make quads
					hidden_edge = IGF.EDGE_V2_V3_HIDDEN
				else:
					hidden_edge = 0
			
			elif num_subfaces is 2:  # Quad: add another triangle
					num1, num2, num3 = 0, 2, 3
					hidden_edge = IGF.EDGE_V0_V1_HIDDEN
			
			for vert_num in (num1, num2, num3):
				vertex_idx = f_v[vert_num]
				#MODIFS2016: vertex colours
				new_colour = IGF.IGsColour()
				if export_v_col:
					v_color = getattr(data.tessface_vertex_colors.active.data[face_num], "color{}".format(str(vert_num+1)))
					new_colour = IGF.IGsColour(*v_color[:3], 1.0)
					
				
				# convert local object coordinates -> world - > local coordinates of first object -> axis change
				local_vertex = common_transform * data.vertices[vertex_idx].co
				
				
				#get the right normals for this vertex:
				local_split_normal = f_split_normals[vert_num]
				assert local_split_normal is not None, "Split normals are NoneType for {} !!".format(obj.name)
				
				if local_split_normal is VNULL3D:
					local_split_normal = data.vertices[vertex_idx].normal
				else:
					#normals are already ok
					pass
				new_normal_rot = common_notransform_rotscale * local_split_normal
				del local_split_normal
				
					
				# Update bounding box in world coordinates
				update_bounding_box(Vmin_bounding_box, Vmax_bounding_box, local_vertex)
				
				
				#get UVs used
				new_UV0 = tuple(IGF.IGsUV(f_uv[vert_num][0], 1 - f_uv[vert_num][1]) for f_uv in f_uv_list)
				# if u_test_mode and not data.tessface_uv_textures:
				# pad with zero or stuff, nobody cares about zeroes!
				if uv_unavailable:
					new_UV0 = tuple(
						IGF.IGsUV(
							(1 if vert_num >= 2 else 0), 
							(1 if ((0 < vert_num <= 2) and (vert_num is not 0)) else 0) )
						for i in range(nb_uvMaps))
					#gives:
					# v0 --> (0,0)
					# v1 --> (0,1)
					# v2 --> (1,1)
					# v3 --> (1,0)
				
				#MODIFS2016: export vertex bindings and weights:
				vertex_bone_binding = []
				if is_skinned:
					#compute values which must add up to 1.0 (using mean)
					bl_v_weights = [(v_wgt.group, v_wgt.weight) for v_wgt in data.vertices[f_v[vert_num]].groups if v_wgt.weight > 0.0]
					total_bl_v_wgt = sum(w for _ , w in bl_v_weights)
					
					
					#sort out too small bone influences
					adjusted_vert_weights = False
					while not adjusted_vert_weights:
						
						adjusted_vert_weights = True #put to False if a non matching elem is found
						
						for idx, (v_g_idx, v_wgt) in enumerate(bl_v_weights):							
							if ((v_wgt / total_bl_v_wgt) < gVertexWeightThreshold) or (v_g_idx not in all_group_indices): #pass bones with not enough influence on export
								
								total_bl_v_wgt -= v_wgt #take them away from calcs
								del bl_v_weights[idx]
								
								adjusted_vert_weights = False
								break
							
					#trim at max bones
					bl_v_weights.sort(key=lambda weight_tuple: weight_tuple[1], reverse=True)
					bl_v_weights = bl_v_weights[:MAX_EXPORTED_BONES]
					
					#look for our bones in our pre-sorted list all_group_names giving bone indices
					for v_g_idx, v_wgt in bl_v_weights:
						#if v_g_idx in all_group_indices:
							#print(bone_name, "found")
						vertex_bone_binding.append(IGF.IGVertexBoneBinding(all_group_indices[v_g_idx], v_wgt / total_bl_v_wgt)) #weights always adds up to 1.0
						#else: #we didn't found something
						#	bpy.ops.igs_err.damned('INVOKE_DEFAULT', type='WARNING', 
						#		message=" VertexBoneBinding processing error: cannot find bone: '{}'".format(obj.vertex_groups[v_g_idx].name))
							#return
							
				elif remote_is_skinned: #enters here if not skinned in Blender only
					vertex_bone_binding.append(IGF.IGVertexBoneBinding(bones_list[0], 1.0))
					#this should be a root bone. anyway, this kind of merge should not happen...
						
				#weld vertices together if possible for performances in TS
				new_vertex = None
				vertex_index = -1
				f_lv = local_vertex.freeze()
				
				looking_for_this = IGF.IGVertex(
					IGF.IGsVector4(local_vertex.x, local_vertex.y, local_vertex.z, 1.0), 
					IGF.IGsVector4(new_normal_rot.x, new_normal_rot.y, new_normal_rot.z,1.0), 
					nb_uvMaps, 
					new_UV0, 
					new_colour, 
					mat_igs_offset,
					len(vertex_bone_binding),
					vertex_bone_binding,
					0,
					mExtraData)
				
				if (f_lv, nb_uvMaps, mat_igs_offset) in object_vertices_params_list:
					vertex_index_set = object_vertices_params_list[f_lv, nb_uvMaps, mat_igs_offset]

					for vi in vertex_index_set:
						if object_vertices_list[vi] == looking_for_this:
							vertex_index, new_vertex = vi, object_vertices_list[vi]
							del looking_for_this
							break
					
				else:
					#used for fast matching vertices
					object_vertices_params_list[f_lv, nb_uvMaps, mat_igs_offset] = set()
					#assures there is a set to receive our future vertex
					
				if new_vertex is not None:
					triangle_vertices_indices_list.append(vertex_index)
					#print(' >>>??? vertex_index ', vertex_index)
				else:  # None
					new_vertex = looking_for_this
					
					object_vertices_list.append(new_vertex)
					object_vertices_params_list[f_lv, nb_uvMaps, mat_igs_offset].add(len(object_vertices_list)-1)
					
					triangle_vertices_indices_list.append(vertices_count)
					vertices_count += 1
				triangle_vertices_list.append(new_vertex)
				
			if materials_list[mat_index][0].mViewFacing > IGF.VF_NONE:
				hidden_edge = 0
			
			# mVertex, mNormal, mHiddenEdges, mMaterial, mSMGroup, mTagId, mExtraData, vertices_list
			# Fill mVertex with vertex index before future update to offset value for the final igs file.
			
			new_triangle = IGF.IGTriangle(
				triangle_vertices_indices_list, face_normal, 
				hidden_edge, 
				mat_igs_offset, 
				data_mp.faces[face_num].smoothgp if data_mp else 0, 
				0, 
				mExtraData, 
				vertices_count_start) # MAJ
			
			object_triangles_list.append(new_triangle)
			triangles_count += 1
	
	# to_mesh() created a new mesh so remove it
	bpy.data.meshes.remove(data)  # @UndefinedVariable
		
	return END_OK, (is_skinned or remote_is_skinned), vertices_count, triangles_count, Vmin_bounding_box, Vmax_bounding_box

def process_mesh_group(Config, IGctn, grp):
		
	local_transform_matrix = (IGctn.global_transform_matrix if grp.LODlevel is 1 else Matrix())

	scale_m = Matrix() #nullify scale
	first_obj_matrix = local_transform_matrix * grp.objects_list[0].matrix_world
	
	scale_m[0][0], scale_m[1][1], scale_m[2][2] = grp.objects_list[0].scale
	first_obj_matrix *= scale_m.inverted()
		
	Vmin_bounding_box = VNULL3D.copy()
	Vmax_bounding_box = VNULL3D.copy()
	object_triangles_count = 0
	object_triangles_list = [] # At group level = at igs mesh level
	grp_vertices_count = 0
	triangles_count_start = IGctn.triangles_count # At group level
	vertices_count_start = IGctn.vertices_count # At group level
	object_vertices_count_start = IGctn.vertices_count # At object level
	is_skinned = False #we register it here to avoid zero bone error in TS when we merge objects
	
	for obj in grp.objects_list:
		# Process objects
		object_vertices_count = 0
		object_vertices_list = [] # At object level
		object_vertices_params_list = dict() # used to find vertices quickly
		
		return_code,  \
		is_skinned,  \
		object_vertices_count, \
		object_triangles_count,  \
		Vmin_bounding_box, Vmax_bounding_box, \
		= process_mesh_geometry(
			obj,
			first_obj_matrix,
            local_transform_matrix,
			Vmin_bounding_box,
			Vmax_bounding_box,
			IGctn.bones_list,
			IGctn.mat_data_index,
			IGctn.materials_list,
			IGctn.materials_sdict,
			object_triangles_list,
			object_vertices_list,
			object_vertices_count,
			object_vertices_count_start,
			object_triangles_count,
			Config,
			IGctn.mExtraData,
			object_vertices_params_list, is_skinned)
	
		if (return_code != END_OK) or (object_vertices_count is 0):
				# return_code == END_ERROR: #if there is no verts, its an error for TS anyway
				raise RuntimeError("IGSE: invalid geometry conversion for object (or dupli) {:s}!".format(obj.name)) from None

		object_vertices_count_start += object_vertices_count # At object level
		IGctn.vertices_list.extend(object_vertices_list) # At object level
		
		grp_vertices_count += object_vertices_count
		#
		#pgr_bar += pgr_b3
		#wm.progress_update(pgr_bar)
		#
	IGctn.triangles_list.extend(object_triangles_list)  # At group level
	IGctn.vertices_count = IGctn.vertices_count + grp_vertices_count
	#
	# Create mesh related items
	new_IGMesh, new_geomLOD, new_instance = create_mesh_igs(grp, first_obj_matrix, IGctn.current_id, is_skinned, grp_vertices_count, object_triangles_count, \
	triangles_count_start, vertices_count_start, Vmin_bounding_box, Vmax_bounding_box, IGctn.mExtraData)
	if new_instance is None:
		raise RuntimeError("IGSE: invalid geometry encoding!") from None
	
	grp.IGinstance_id = int(IGctn.current_id)
	IGctn.current_id += 1
	if grp_vertices_count: # Mesh
		IGctn.meshes_count += 1
		IGctn.meshes_list.append(new_IGMesh)
		IGctn.meshesLODs_list.append(new_geomLOD)
		IGctn.triangles_count += object_triangles_count
	IGctn.instances_list.append(new_instance)
	
def create_mesh_igs(grp, 
	matrix, 
	current_id, 
	is_skinned, 
	vertices_count, 
	triangles_count, 
	triangles_count_start, 
	vertices_count_start,
	Vmin_bounding_box, 
	Vmax_bounding_box, 
	mExtraData): #MODIFS2016: is_skinned adapt
#MODIF2016: err handling implem
# error struct ref: bpy.ops.igs_err.damned('EXEC_DEFAULT', type='INFO', message="")
	children_count = len(grp.child_groups_list)
	if children_count > IGF.MAX_CHILDREN:
		bpy.ops.igs_err.damned('INVOKE_DEFAULT', type='ERROR', message=" more than {:d} children (max children) for object {:s} (check groups list above)".format(IGF.MAX_CHILDREN, grp.name))
		return None, None, None
	
	if vertices_count is 0: # Empty alone in a group (should not occur as empty's are dropped when scanning the model to build groups)
		new_IGMesh, new_geomLOD = None, None
		mNumLODs = 0
		mGeometry = 0
	else: # Mesh
		# Update bounding box in world coordinates to avoid disappearing object when near camera
		update_bounding_box(Vmin_bounding_box, Vmax_bounding_box, matrix.to_translation())
		
		MyPointMin = IGF.IGsVector4(Vmin_bounding_box.x, Vmin_bounding_box.y, Vmin_bounding_box.z, 1.0)
		MyPointMax = IGF.IGsVector4(Vmax_bounding_box.x, Vmax_bounding_box.y, Vmax_bounding_box.z, 1.0)
		bounding_box = IGF.IGsBoundingBox(MyPointMin, MyPointMax)
		
		# mIsSkinned, mNumVertices, mVertices, mNumTriangles, mTriangles, mBoundingBox, mExtraData
		new_IGMesh = IGF.IGGeom(is_skinned, 
							vertices_count, vertices_count_start, 
							triangles_count, triangles_count_start, 
							bounding_box, 
							mExtraData)
		
		# VisibleDistance, pGeometry, mExtraData
		new_geomLOD = IGF.IGGeometryLOD(grp.LODdist, current_id, mExtraData)
		
		mNumLODs = 1
		mGeometry = current_id
	if grp.parent_group:
		matrix_w = grp.parent_group.objects_list[0].matrix_world.inverted() * grp.objects_list[0].matrix_world
	else:
		matrix_w = matrix
	myMatrix  = IGF.IGsMatrix4x4.new_to_TS_screenspace(matrix_w)
	myMatrix2 = IGF.IGsMatrix4x4.new_to_TS_screenspace(matrix_w) #used as initial TM to resolve parenting later on export
	
	# mName, mNameUID, mNumLODs, mGeometry, mTM, mParent, mNumChildren, mChildren, ExtraData, parent_group, child_groups_list
	new_instance = IGF.IGInstance(grp.name, current_id, mNumLODs, mGeometry, myMatrix, 0, children_count, [], \
	mExtraData, myMatrix2, grp.parent_group, grp.child_groups_list)
	grp.IGinstance = new_instance
	
	return new_IGMesh, new_geomLOD, new_instance


#======================================ARMATURES

def create_bones_igs(IGctn, armat): #MODIFS2016: Bones
	
	def create_a_bone(current_bone, root_mtrx=Matrix.Identity(4)):
		b_name = current_bone.name
		b_uid = IGctn.bones_count + 1 #bones_count is used as UID
		
		matrix = root_mtrx * current_bone.matrix_local
		b_TM = IGF.IGsMatrix4x4.new_to_TS_screenspace(matrix)
		
		try: 
			b_parent = current_bone.parent.name
		except AttributeError: 
			b_parent = None
	
		b_children = []
		for b_child in current_bone.children: #register children
			b_children.append(b_child.name)
		
		new_bone = IGF.IGBone(b_name, b_uid, b_TM, b_parent, b_children, IGctn.mExtraData)
		
		return new_bone
	
	armat.data.pose_position = 'REST'
	b_error = False
	for i, bone in enumerate(armat.data.bones):
		if bone.parent is None:
			rt_mtrx = IGctn.global_transform_matrix * armat.matrix_world
			new_bone = create_a_bone(bone, rt_mtrx)
		else:
			rt_mtrx = (armat.matrix_world * bone.parent.matrix_local).inverted()
			new_bone = create_a_bone(bone, rt_mtrx)
		IGctn.bones_list.append(new_bone)
		IGctn.bones_count += 1
		
	#end creation, now link parents
	else:
		#update relationship names to offsets:
		for bone in IGctn.bones_list[:]:
			#update parent:
			if bone.mParent:
				mPBoneName = bone.mParent.encode()
				for num_bone, bone2 in enumerate(IGctn.bones_list):
					if bone2.mName == mPBoneName:
						bone.mParent = num_bone + 1 #Else it's impossible to know if there is no parent or parent is first of list
						break
				else:
					bpy.ops.igs_err.damned('EXEC_DEFAULT', type='WARNING', message=" Bone parent not found. Bone '{0}' looking for '{1}'".format(bone.mName.decode(), bone.mParent))
					b_error = True
			#update children:
			if bone.mChildren:
				for j, b_child in enumerate(bone.mChildren[:]):
					mCBoneName = b_child.encode()
					for num_bone, bone2 in enumerate(IGctn.bones_list):
						if bone2.mName == mCBoneName:
							bone.mChildren[j] = num_bone
							break
					else:
						bpy.ops.igs_err.damned('EXEC_DEFAULT', type='WARNING', message=" Bone child not found. Bone '{0}' looking for '{1}'".format(bone.mName.decode(), mCBoneName))
						b_error = True
		if b_error:
			#error safety
			bpy.ops.igs_err.damned('INVOKE_DEFAULT', type='ERROR', message=" Bone offset processing error. See log")
			return None, None
		return
	#error safety
	bpy.ops.igs_err.damned('INVOKE_DEFAULT', type='ERROR', message=" Unknown error with bones generation happened!!")
	return

	
#======================================SNAP POINTS

def create_snapp_igs(IGctn, grp): #MODIFS2016: Snap points
	obj = grp.objects_list[0]
	
	if obj.empty_draw_type == 'ARROWS' and len(obj.children) is 0:
		name_split = grp.name.split('_')
		if ('#s' in name_split[0]) and (len(name_split[0]) == 3):
			if len(obj.name) > IGF.MAX_OBJECT_NAME:
				s_name = grp.name[:IGF.MAX_OBJECT_NAME]
				bpy.ops.igs_err.damned('EXEC_DEFAULT',type='WARNING', message=" Snap Point '{:s}' processed using a truncated name at {:d} characters: '{:s}' (to comply with naming rule).".format(grp.name, MAX_NAME_WITH_LOD, s_name))
			else:
				s_name = grp.name
				
			s_name = s_name[1:] #stripping "#"
			
			matrix = IGctn.global_transform_matrix * obj.matrix_world
			s_TM = IGF.IGsMatrix4x4.new_to_TS_screenspace(matrix)
			
			MyPointMin = IGF.IGsVector4()
			MyPointMax = IGF.IGsVector4()
			s_BoundingBox = IGF.IGsBoundingBox(MyPointMin, MyPointMax)
			
			s_Parent = 0
			if obj.parent:
				for i, instance in enumerate(IGctn.instances_list):
					if instance.mName.decode() == obj.parent.name:
						s_Parent = i + 1
			
			s_Data = IGF.IGGenericSceneData(0, (0,0,0,0), (0.0,0.0,0.0,0.0),  IGctn.mExtraData)
			new_snap_point = IGF.IGGenericSceneItem(s_name, IGctn.gscitems_count, s_TM, s_BoundingBox, s_Parent, s_Data)
			
			IGctn.gscitems_list.append(new_snap_point)
			IGctn.gscitems_count += 1
			bpy.ops.igs_err.damned('EXEC_DEFAULT', type='INFO', message=" '{0}' computed as snap point: '{1}'".format(obj.name, s_name))
			


#======================================MISC FUNCS

def update_matrix(instance): #recursive
	# Update matrix to take hierarchy into account
	iTM = instance.mInitialTM.get_matrix()
	for instance_child in instance.child_groups_list:
		if instance_child.IGinstance is not None:
			instance_child.IGinstance.mTM.update_from_parent(iTM)
			update_matrix(instance_child.IGinstance)

	
#====================================================================EXPORT
#MODIFS2016: progress bar implementation, is_skinned adapt, bone adapt

class IGArrays():
	"""Container for IGS offsets and lists
	for easier transformations"""
	
	def __init__(self):
		self.global_transform_matrix = Matrix()
		
		self.materials_list = []
		self.materials_sdict = dict()
		self.mat_data_index = None
		
		self.meshes_list = []
		self.meshesLODs_list = []
		self.instances_list = []
		self.triangles_list = []
		self.vertices_list = []
		self.textures_list = []
		self.lights_list = []
		self.splines_list = []
		self.bones_list = []
		self.gscitems_list = []
		
		self.add_face_tag_description = False
		#
		self.current_id = 0
		self.triangles_count = 0
		self.vertices_count = 0
		self.meshes_count = 0
		self.materials_count = 0
		self.bones_count = 0
		self.gscitems_count = 0
		
		self.mExtraData = IGF.IGDataBlockContainer()

def ExportIGS(Config, pgrh):
	""" Bl_data.IGSExporterSettings(bpy.types.PropertyGroup) * context.window_manager
	-> str or NoneType
	wrapper for the real exporter, protects users scenes  """
	
	if PROFILE_MODE:
		import cProfile, pstats, io
		pr = cProfile.Profile()
		s = io.StringIO()
		pr.enable()
	
	
	pgrh.update(0, "Cleaning Scene...")
	wrapper = CleanAndProperSceneExport(Config)
	with wrapper as objects_list:
		if not objects_list:
			raise RuntimeError("BRIAGE: Empty object list! check Blender console or log file") from None
		
		export_errors = _internal_ExportIGS(wrapper.Config, pgrh, objects_list)
		
	if PROFILE_MODE:
		pr.disable()
		sortby = 'tottime'
		pstats.Stats(pr, stream=s).sort_stats(sortby).print_stats(20)
		sortby = 'cumtime'
		pstats.Stats(pr, stream=s).sort_stats(sortby).print_stats(20)
		#print(s.getvalue())
		try:
			with open("ExportIGS.log", "w") as f:
				f.write(s.getvalue())
		except:
			print("BRIAGE: Cannot print profile log, turn off Profiling mode")
			
	return export_errors or None

def _internal_ExportIGS(Config, pgrh, objects_list):
# error struct ref: bpy.ops.igs_err.damned('EXEC_DEFAULT', type='INFO', message="")
	# Current  model directory name
	model_directory = os.path.dirname(bpy.path.abspath(Config.FilePath))
	# Current model file name
	model_name = os.path.basename(Config.FilePath)
	# Name without suffix
	filename_strip = os.path.splitext(model_name)[0]
	#
	IGctn = IGArrays()
	#
	pgrh.update(5, "Resolving materials and checking consistency...")
	#
	#
	#Check scene for errors
	IGctn.mat_data_index = checkScene(Config, objects_list)
# 	if PROFILE_MODE:
# 		print("--> " + str(IGctn.mat_data_index))
	if not IGctn.mat_data_index: 
		# print("IGSE: empty id material list!")
		return
	bpy.ops.igs_err.damned('EXEC_DEFAULT', type='INFO', message=" The scene is clean and ready for export")
	#
	#Center Main Object
	IGctn.global_transform_matrix = center_main_object(Config)
	
	pgrh.update(15, "Generating groups...")
	#
	#print(" Main object selected = {:s}".format(main_obj.name))
	bpy.ops.igs_err.damned('EXEC_DEFAULT', type='INFO', message=" Generating groups...")
	#
	# Sort objects in groups
	groups_list = make_groups(Config, objects_list)
	
	#
	pgrh.update(25, "Converting bones & armatures...")
	#
	#'''-----------------------------------------------'''
	#'''Save the sorted Blender scene into igs objects.'''
	#'''-----------------------------------------------'''
	#
	#
	add_face_tag_description = False
	#
	bpy.ops.igs_err.damned('EXEC_DEFAULT', type='INFO', message=" Converting bones & armatures...")
	#sort armatures out and process bones:
	if Config.process_bones:
		for armature in [obj for obj in objects_list if obj.type == 'ARMATURE']:
			if Config.Verbose or PROFILE_MODE:
				bpy.ops.igs_err.damned('EXEC_DEFAULT', type='INFO', message="   +> "+armature.name)
			create_bones_igs(IGctn, armat=armature)
	#
	pgr_bar = 30
	try: pgr_b2 = abs(40 / len(groups_list))
	except: pgr_b2 = 1
	#
	bpy.ops.igs_err.damned('EXEC_DEFAULT', type='INFO', message=" Converting Materials...")
	#Process materials
	create_materials_igs(Config, IGctn)
	#
	bpy.ops.igs_err.damned('EXEC_DEFAULT', type='INFO', message=" Converting Meshes and items...")
	
	#matrix to transform vectors into TS instance local space
	#TO_TS_MATRIX = Matrix.Rotation(radians(90), 4, 'X') * Matrix.Scale(-1, 4, Vector((0, 0, 1)))
	
	for grp in groups_list:
		#first_obj_matrix = (IGctn.global_transform_matrix if grp.LODlevel is 1 else Matrix()) * \
		#	grp.objects_list[0].matrix_world * grp.objects_list[0].matrix_basis.inverted()
		#
		#if Config.Verbose or PROFILE_MODE:
		#	bpy.ops.igs_err.damned('EXEC_DEFAULT', type='INFO', message="   +> "+grp.name)
			
		assert grp.type_o in {'MSH', 'SPT'} , "IGSE: Invalid group, see previous error(s) in Blender Console"
		
		if grp.type_o is 'MSH':
			process_mesh_group(Config, IGctn, grp)
		
		elif grp.type_o is 'SPT':
			#process snap points:
			create_snapp_igs(IGctn, grp)
		#
		pgr_bar += pgr_b2
		pgrh.update(pgr_bar, grp.name)
	#
	assert IGctn.materials_count > 0 , "IGSE: No material found: Export stopped, see previous error(s) in Blender Console"
	assert IGctn.vertices_count > 0 , "IGSE: No vertex found: Export stopped, see previous error(s) in Blender Console"
	assert IGctn.triangles_count > 0 , "IGSE: No triangle found: Export stopped, see previous error(s) in Blender Console"
	assert IGctn.meshes_count > 0 , "IGSE: No mesh found: Export stopped, see previous error(s) in Blender Console"
	#
	#
	pgr_bar = 70
	pgrh.update(pgr_bar, "Generating header and offsets...")
	#
	# Update data to deal with actual offsets in the future IGS file
	datablocks_count = 1
	if add_face_tag_description:
		datablocks_count = 2
	#
	objects_count = IGctn.meshes_count
	start_materials_offset = IGF.HEADER_SIZE 
	start_vertices_offset = IGF.HEADER_SIZE + IGctn.materials_count * IGF.MATERIAL_SIZE 
	start_triangles_offset = start_vertices_offset + IGctn.vertices_count * IGF.VERTEX_SIZE 
	start_geom_offset = start_triangles_offset + IGctn.triangles_count * IGF.TRIANGLE_SIZE 
	start_geomLOD_offset = start_geom_offset + IGctn.meshes_count * IGF.GEOM_SIZE 
	start_instance_offset = start_geomLOD_offset + IGctn.meshes_count * IGF.GEOMLOD_SIZE 
	start_bones_offset = start_instance_offset + IGctn.meshes_count * IGF.INSTANCE_SIZE #MODIFS2016: bones
	start_gscitems_offset = start_bones_offset + IGctn.bones_count * IGF.BONE_SIZE #MODIFS2016: gscitems
	start_datablocks_offset = start_gscitems_offset + IGctn.gscitems_count * IGF.GSCITEMS_SIZE
	
	if IGctn.bones_count is 0: start_bones_offset = 0
	if IGctn.gscitems_count is 0: start_gscitems_offset = 0
	if datablocks_count is 0: start_datablocks_offset = 0
	#
	if add_face_tag_description:
		#face_tag_description_start = start_datablocks_offset + (datablocks_count * IGF.DATABLOCK_SIZE)
		#absolute_texture_name_start = face_tag_description_start + IGF.MAX_FACE_TAG_DESCS * IGF.MAX_OBJECT_NAME
		start_face_tag_description_offset = datablocks_count * IGF.DATABLOCK_SIZE # Relative to start of datablocks
		start_texturenames_offset = (datablocks_count * IGF.DATABLOCK_SIZE) + (IGF.MAX_FACE_TAG_DESCS * IGF.MAX_OBJECT_NAME) # start_texturenames_offset is relative to start of datablocks
	else:
		#absolute_texture_name_start = start_datablocks_offset + (datablocks_count * IGF.DATABLOCK_SIZE)
		start_texturenames_offset = datablocks_count * IGF.DATABLOCK_SIZE # start_texturenames_offset is relative to start of datablocks
	#
	bpy.ops.igs_err.damned('EXEC_DEFAULT', type='INFO', message=" Converting textures...")
	# Texture file names
	texture_names = IGF.IGTextureNames(IGctn.textures_list)
	#
	if add_face_tag_description:
		# mName, mID, mData, mSize / UniqueID = 1
		face_tag_description_data_block = IGF.IGDataBlock('Face tag descriptions', IGF.BLOCK_FACE_TAG_DESCS, start_face_tag_description_offset, 0)
		list_of_tags = [b'IG_TAG_NONE', \
		b'IG_TAG_HEAD' , b'IG_TAG_HEAD_STUMP' , b'IG_TAG_HEAD_STUMP_REPL' , \
		b'IG_TAG_ARM_L', b'IG_TAG_ARM_L_STUMP', b'IG_TAG_ARM_L_STUMP_REPL', \
		b'IG_TAG_ARM_R', b'IG_TAG_ARM_R_STUMP', b'IG_TAG_ARM_R_STUMP_REPL', \
		b'IG_TAG_LEG_L', b'IG_TAG_LEG_L_STUMP', b'IG_TAG_LEG_L_STUMP_REPL', \
		b'IG_TAG_LEG_R', b'IG_TAG_LEG_R_STUMP', b'IG_TAG_LEG_R_STUMP_REPL']
		face_tag_description = IGF.IGFaceTagDescription(list_of_tags)
	#
	# mName, mID, mData, mSize / UniqueID = 2
	textures_data_block = IGF.IGDataBlock('Texture name table', IGF.BLOCK_TEXTURE_NAMES, start_texturenames_offset, 0)
	#
	bpy.ops.igs_err.damned('EXEC_DEFAULT', type='INFO', message=" Writing header...")
	# Initialize Header structure
	#MODIFS2016: object color from main object:
	IGobject_color = IGF.IGsColour(objects_list[0].color[0],objects_list[0].color[1],objects_list[0].color[2],objects_list[0].color[3]) #MODIFS2016: object color = main obj color
	blender_version = ".".join(str(i) for i in bpy.app.version)  # @UndefinedVariable
	exporter_version = IGSE_VERSION
	IGDescriptor = b"SHAPE"
	myComment = ('Blender ' + blender_version + ' - ' + exporter_version)
	myHeader = IGF.IGHeader(IGDescriptor,
		myComment[:IGF.MAX_HEADER_COMMENT], 0, 
		objects_count, start_instance_offset, 
		IGctn.meshes_count, start_geom_offset, 
		IGctn.bones_count, start_bones_offset, 
		IGctn.materials_count, start_materials_offset, 
		0, 0, #lights
		IGobject_color,  #ambient color...
		0, 0, #splines
		IGctn.gscitems_count, start_gscitems_offset, 
		datablocks_count, 0, 
		start_datablocks_offset) #MODIFS2016: bones, gscitems
	#
	bpy.ops.igs_err.damned('EXEC_DEFAULT', type='INFO', message=" Updating offsets...")
	# Update offset values
	# --------------------
	#
	for vertex in IGctn.vertices_list:
		for b_binding in vertex.mBoneBinding:
			b_binding.mBone = start_bones_offset + b_binding.mBone * IGF.BONE_SIZE
	#
	for triangles in IGctn.triangles_list:
		for i in range(3):
			#print(' >>>??? triangles.mVertex[i]', triangles.mVertex[i])
			triangles.mVertex[i] = start_vertices_offset + triangles.mVertex[i] * IGF.VERTEX_SIZE
	#
	for mesh in IGctn.meshes_list:
		# mIsSkinned, mNumVertices, mVertices, mNumTriangles, mTriangles, mBoundingBox, mExtraData
		mesh.mVertices = start_vertices_offset + mesh.mVertices * IGF.VERTEX_SIZE
		mesh.mTriangles = start_triangles_offset + mesh.mTriangles * IGF.TRIANGLE_SIZE
	#
	for meshLOD in IGctn.meshesLODs_list:
		# VisibleDistance, pGeometry, mExtraData
		meshLOD.pGeometry = start_geom_offset + meshLOD.pGeometry * IGF.GEOM_SIZE
	#
	for instance in IGctn.instances_list:
		instance.mGeometry = start_geomLOD_offset + instance.mGeometry * IGF.GEOMLOD_SIZE

	# Update gscitems for parent offset
	# ---------------------------------------------
	#
	for snapp in IGctn.gscitems_list:
		# Parent offset
		if snapp.mParent:
			snapp.mParent = start_instance_offset + (snapp.mParent - 1) * IGF.INSTANCE_SIZE
		
	# Update bones for parent / children offset
	# ---------------------------------------------
	#
	for bone in IGctn.bones_list:
		# Parent offset
		if bone.mParent:
			bone.mParent = start_bones_offset + (bone.mParent - 1) * IGF.BONE_SIZE
		# Children offset
		for b_child_num in range(0, len(bone.mChildren)):
			bone.mChildren[b_child_num] = start_bones_offset + bone.mChildren[b_child_num] * IGF.BONE_SIZE
	
	# Update instances for parent / children offset
	# ---------------------------------------------
	#
	for instance in IGctn.instances_list:
		# Parent offset
		if instance.parent_group is None:
			instance.mParent = 0
			# Update matrix to take hierarchy into account
			# (igs rotation and translation in a child object are relative to its parent)
			#update_matrix(instance)
		else:
			instance.mParent = start_instance_offset + instance.parent_group.IGinstance_id * IGF.INSTANCE_SIZE
		# Children offset
		#print(' >>>> ', instance.mName, len(instance.child_groups_list))
		for child in instance.child_groups_list:
			# child_groups_list is a list of 'group_wrapper' / mChildren was initialized to empty list
			instance.mChildren.append(start_instance_offset + child.IGinstance_id * IGF.INSTANCE_SIZE)
	#
	#	
	#	
	pgr_bar = 75
	pgrh.update(pgr_bar, "Writing to file...")
	#
	bpy.ops.igs_err.damned('EXEC_DEFAULT', type='INFO', message=" Writing to materials file...")
	#
	# Open the file for writing igs data
	file = open(model_directory + '\\' + filename_strip + '.igs', 'wb')
	# 
	#
	myHeader.write(file)
	print_pr(2)
	myHeader.dump_log(Config.Verbose)
	#
	print('================================================================================')
	print('Materials list ({:d} materials):'.format(IGctn.materials_count))
	print('--------------------------------------------------------------------------------')
	print(" {:^20} | {:^30} | {:^40} / {:s}".format("Name", "Shader", "First texture", "UVArguments"))
	for i in range(IGctn.materials_count):
		IGctn.materials_list[i][0].dump_log(i+1, IGctn.materials_count, start_materials_offset + i * IGF.MATERIAL_SIZE, texture_names, False, Config.Verbose)
	print('================================================================================')
	#
	if Config.Verbose:
		print('IGfMaterials                  : [ {:d} ]'.format(IGctn.materials_count))
	for i in range(IGctn.materials_count):
		#IGctn.materials_list[i][0].write(file)
		if Config.Verbose:
			IGctn.materials_list[i][0].dump_log(i+1, IGctn.materials_count, start_materials_offset + i * IGF.MATERIAL_SIZE, texture_names, True, Config.Verbose)
		IGctn.materials_list[i][0].write(file)
	#
	pgr_bar = 80
	pgrh.update(pgr_bar, "Writing verts to file...")
	if Config.Verbose:
		print('================================================================================')
		print('IGfVerts                      : [ {:d} ]'.format(IGctn.vertices_count))
	vl = IGctn.vertices_list
	for i in range(IGctn.vertices_count):
		vl[i].write(file)
		if Config.Verbose:
			vl[i].dump_log(i+1, IGctn.vertices_count, start_vertices_offset + i * IGF.VERTEX_SIZE )
	#
	pgr_bar = 85
	pgrh.update(pgr_bar, "Writing tris to file...")
	if Config.Verbose:
		print('================================================================================')
		print('IGfTriangles                  : [ {:d} ]'.format(IGctn.triangles_count))
	tl = IGctn.triangles_list
	for i in range(IGctn.triangles_count):
		tl[i].write(file)
		if Config.Verbose:
			tl[i].dump_log(i+1, IGctn.triangles_count, start_triangles_offset + i * IGF.TRIANGLE_SIZE )
	#
	pgr_bar = 90
	pgrh.update(pgr_bar, "Writing instances to file...")
	#
	if Config.Verbose:
		print('================================================================================')
		print('IGfMeshes                     : [ {:d} ]'.format(IGctn.meshes_count))
	for i in range(IGctn.meshes_count):
		IGctn.meshes_list[i].write(file)
		if Config.Verbose:
			IGctn.meshes_list[i].dump_log(i+1, IGctn.meshes_count, start_geom_offset + i * IGF.GEOM_SIZE)
			#
	if Config.Verbose:
		print('================================================================================')
		print('IGfMeshLODs                   : [ {:d} ]'.format(IGctn.meshes_count))
	for i in range(IGctn.meshes_count):
		IGctn.meshesLODs_list[i].write(file)
		if Config.Verbose:
			IGctn.meshesLODs_list[i].dump_log(i+1, IGctn.meshes_count, start_geomLOD_offset + i * IGF.GEOMLOD_SIZE)
	#
	if Config.Verbose:
		print('================================================================================')
		print('IGfObjects                    : [ {:d} ]'.format(IGctn.meshes_count))
	for i in range(IGctn.meshes_count):
		IGctn.instances_list[i].write(file)
		if Config.Verbose:
			IGctn.instances_list[i].dump_log(i+1, IGctn.meshes_count, start_instance_offset + i * IGF.INSTANCE_SIZE)
	#
	#MODIFS2016: bones
	if Config.Verbose:
		print('================================================================================')
		print('IGfBones                    : [ {:d} ]'.format(IGctn.bones_count))
	for i in range(IGctn.bones_count):
		IGctn.bones_list[i].write(file)
		if Config.Verbose:
			IGctn.bones_list[i].dump_log(i+1, IGctn.bones_count, start_bones_offset + i * IGF.BONE_SIZE)
	#
	#MODIFS2016: snap points
	if Config.Verbose:
		print('================================================================================')
		print('IGfGenericSceneItem           : [ {:d} ]'.format(IGctn.gscitems_count))
	for i in range(IGctn.gscitems_count):
		IGctn.gscitems_list[i].write(file)
		if Config.Verbose:
			IGctn.gscitems_list[i].dump_log(i+1, IGctn.gscitems_count, start_gscitems_offset + i * IGF.GSCITEMS_SIZE)
	#
	if Config.Verbose:
		print('================================================================================')
		print('IGfDataBlocks                 : [ {:d} ]'.format(datablocks_count))
		num_block = 1
		if add_face_tag_description:
			face_tag_description_data_block.dump_log(1, datablocks_count, start_datablocks_offset)
			num_block = 2
		textures_data_block.dump_log(num_block, datablocks_count, start_datablocks_offset + (num_block - 1) * IGF.DATABLOCK_SIZE)
	if add_face_tag_description:
		face_tag_description_data_block.write(file)
	textures_data_block.write(file)
	if add_face_tag_description:
		if Config.Verbose:
			face_tag_description.dump_log(start_datablocks_offset + 2 * IGF.DATABLOCK_SIZE)
		face_tag_description.write(file)
	texture_names.write(file)
	#
	print('================================================================================')
	texture_names.dump_log(1, 1, start_texturenames_offset)
	#
	# Close the file:
	file.close()
	del IGctn
	#
	pgr_bar = 100
	pgrh.update(pgr_bar, "Reverting Scene...")
	#
	return 'FINISHED'
