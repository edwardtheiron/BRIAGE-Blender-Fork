﻿# ##### BEGIN LICENSE BLOCK #####
#
# Copyright (C) 2018 'Juju49'(MERLE-RÉMOND Julian)
# see license notes __init__.py
#
# ##### END LICENSE BLOCK #####

import bpy

import os

from . Bl_data import (
	SHORT_SHADER_NAME_DIC,
	SHADERS_LIST,
	SHADERS_ENUM)

from ._datastructs.IGF import gVertexWeldNormalThreshold


PROFILE_MODE = True

error_bias = 8 #error code above this value are counted as errors and not warnings only
	

def _checkMaterial(Config, material):
	error_flags = 0
	texslots = material.texture_slots
	# check properties of applied materials texture slots
	valid_tsl = [tsl for tsl in texslots if (tsl and tsl.use)]
	num_slot = len(valid_tsl)
	
	if (num_slot == 0):
		mShaderName = material.IgsMat.shader_name
		if mShaderName == 'custom' or len(SHADERS_ENUM) == 1: 
			mShaderName = material.IgsMat.shader_name_string
		
		#error_flags += 0b10 #warning2
		#bpy.ops.igs_err.damned('EXEC_DEFAULT',type='INFO', message=" Material '{1}' is not using any texture with shader '{0}'.".format(mShaderName, material.name))
		
		if mShaderName in SHADERS_LIST:
			if (int(SHADERS_LIST[mShaderName][1]) != num_slot):
				error_flags += 0b10000 << error_bias#error16
				if not Config.u_test_mode:
					bpy.ops.igs_err.damned('INVOKE_DEFAULT',type='ERROR', 
						message=" Incorrect number of slots for shader name {0} used in material named {1}, {2} texture slots must be set in Blender; {3} found".format(mShaderName, material.name, SHADERS_LIST[mShaderName][1], num_slot))
				return error_flags
			
	
	for j, txslot in enumerate(valid_tsl):
		#check shader name validity
		if j is 0:
			if txslot.texture.type == 'NONE':
				num_slot -= 1
				error_flags += 0b1 #warning1
				bpy.ops.igs_err.damned('EXEC_DEFAULT',type='WARNING', 
					message="{:s} in material {:s} using deprecated shader naming feature!".format(txslot.name, material.name))
				try:
					mShaderName = SHORT_SHADER_NAME_DIC[txslot.name]
				except KeyError:
					mShaderName = txslot.name
					
			else:
				mShaderName = material.IgsMat.shader_name
				if mShaderName == 'custom' or len(SHADERS_ENUM) == 1: 
					mShaderName = material.IgsMat.shader_name_string
			
			if (num_slot == 0):
				error_flags += 0b10 #warning2
				bpy.ops.igs_err.damned('EXEC_DEFAULT',type='INFO', message=" Material '{1}' is not using any texture with shader '{0}'.".format(mShaderName, material.name))

			if mShaderName in SHADERS_LIST:
				if (int(SHADERS_LIST[mShaderName][1]) != num_slot):
					error_flags += 0b10000  << error_bias#error16
					if not Config.u_test_mode:
						bpy.ops.igs_err.damned('INVOKE_DEFAULT',type='ERROR', 
							message=" Incorrect number of slots for shader name {0} used in material named {1}, {2} texture slots must be set in Blender; {3} found".format(mShaderName, material.name, SHADERS_LIST[mShaderName][1], num_slot))
					return error_flags
					
			if (mShaderName.find('WeatherEffects') >= 0) and (num_slot == 1):
				name_split = material.name.split('_')
				if (len(name_split) != 2) or (name_split[0] != 'weatherglass') or not (name_split[1].isdigit()):
					error_flags += 0b100000  << error_bias#error128
					if not Config.u_test_mode:
						bpy.ops.igs_err.damned('INVOKE_DEFAULT',type='ERROR', 
							message=" With shader name TrainGlassWeatherEffects.fx, material name must be weatherglass_1, weatherglass_2, etc.. ('{:s}' was found)".format(material.name))
					return error_flags
						
			del mShaderName
			
		if txslot.texture.type == 'IMAGE':
			#check textures
			f_ext = (txslot.texture.IgsTex.final_tex_file_path).rfind('.')
			
			if txslot.texture.image is None: #if no image assigned
				error_flags += 0b100000 << error_bias #error32
				if not Config.u_test_mode:
					bpy.ops.igs_err.damned('INVOKE_DEFAULT',type='ERROR', 
						message=" Missing image file in material '{0}', in texture slot '{1}'".format(material.name, txslot.texture.name))
				return error_flags
			
			texture_file_name = txslot.texture.image.filepath
			tfn_test = os.path.basename(texture_file_name)
				
			if tfn_test is not "":
				ext = tfn_test.rfind('.')
				if (ext is -1) and (f_ext is -1): #if no other texture path can be assigned
					error_flags += 0b100000 << error_bias #error32
					if not Config.u_test_mode:
						bpy.ops.igs_err.damned('INVOKE_DEFAULT',type='ERROR', 
							message=" Missing image file in material '{0}', in texture slot '{1}'".format(material.name, txslot.texture.name))
					return error_flags
				
				texture_file_name = tfn_test[:ext]
			
			else: #fallback mode if os.path.basename fails to compute correctly
				ext = texture_file_name.rfind('.')
				if (ext is -1) and (f_ext is -1): #if no other texture path can be assigned
					error_flags += 0b100000 << error_bias #error32
					if not Config.u_test_mode:
						bpy.ops.igs_err.damned('INVOKE_DEFAULT',type='ERROR', 
							message=" Missing image file in material '{0}', in texture slot '{1}'".format(material.name, txslot.texture.name))
					return error_flags
				
				base = texture_file_name.rfind('\\')
				if base is not -1:
					texture_file_name = texture_file_name[base+1:ext]
			del tfn_test
			
			# Process texture file substitution   # MAJ_1_4_0b #MODIFS2016
			for strings in Config.texture_string_to_replace: #texture name replace mode
				if "#" == strings.name[0]:
					if strings.name[1:] == texture_file_name:
						texture_file_name = strings.prop1
						
			for strings in Config.texture_string_to_replace: #string replace mode
				if (strings.name in texture_file_name) and ("#" != strings.name[0]):
					texture_file_name = texture_file_name.replace(strings.name, strings.prop1)
			# =================================================convert texture_file_name to path
			
			if texture_file_name.count(".") > 1:
					error_flags += 0b100 #warning4
					bpy.ops.igs_err.damned('EXEC_DEFAULT',type='WARNING', 
						message=" Image filename '{0}' contains dots '.' which will cause unexpected results in material '{1}', in texture slot '{2}'".format(txslot.texture.image.filepath, material.name, txslot.texture.name))
						#jan2020 errors with numbered fields fixed
					texture_file_name += ".safe"
			
			# Add specific target:
			if txslot.texture.IgsTex.use_source_tex_file_path:
				ext = (txslot.texture.image.filepath).rindex('.')
				texture_file_name = txslot.texture.image.filepath[:ext]
			
			elif f_ext is not -1: 
				texture_file_name = (txslot.texture.IgsTex.final_tex_file_path)[:f_ext]
			
			# Add target textures directory:
			else:
				texture_file_name = Config.target_textures_directory + "\\" + texture_file_name
			
			#MODIFS2016 Remap paths:
			ref_path = bpy.path.abspath("//")
			if Config.remap_to_igf:
				ref_path = os.path.dirname(bpy.path.abspath(Config.FilePath))
				
			try:
				texture_file_name = (bpy.path.relpath(bpy.path.abspath(texture_file_name), ref_path)).lstrip("/")
			except ValueError as VE:
				p_args = (VE.args[0]).split(',')
				p_texname = bpy.path.basename(texture_file_name)
				error_flags += 0b1000000 << error_bias #error64
				if not Config.u_test_mode:
					bpy.ops.igs_err.damned('INVOKE_DEFAULT', type='ERROR', 
						message="Final IGS export path {1} .  But textures {0} .  Please, export to the same drive your data are from!  Texture '{2}' not added from '{3}'".format(p_args[0], p_args[1], p_texname, texture_file_name))
					bpy.ops.igs_err.damned('EXEC_DEFAULT',type='ERROR',
						message=" Cannot link image file in material '{0}', in texture slot '{1}'".format(material.name, txslot.texture.name))
				return error_flags
	return error_flags

def _checkMesh(Config, ob):
	""" Config, ob -> error_flags, mat_data_index
	
		Checks if ob is ready for export according to Config values"""
	error_flags = 0
	mat_data_index = set()
	should_add_test_mat = False
	
	tf_data = ob.to_mesh(Config.context.scene, True, 'PREVIEW') # Create mesh object
	tf_data.calc_tessface()
	
	#check if UVs exist
	if (not tf_data.tessface_uv_textures) and (not Config.u_test_mode):
		error_flags += 0b1 << error_bias #error1
		bpy.ops.igs_err.damned('INVOKE_DEFAULT', type='ERROR', 
			message=" Blender Mesh object '{:s}' has no collection of UV maps for tessellated faces (check material assignement).".format(ob.name))
		return error_flags, mat_data_index
	
	
	#test face(s) or present
	if len(tf_data.tessfaces) is 0:
		error_flags += 0b10 << error_bias #error2
		bpy.ops.igs_err.damned('INVOKE_DEFAULT', type='ERROR', 
			message=" Blender Mesh object '{:s}' has no face(s)!!".format(ob.name))
		return error_flags, mat_data_index
	
	#list materials applied and test face area:
	applied_set = set()
	face_area_problems_already = False
	
	if not len(tf_data.materials):
		if Config.u_test_mode:
			should_add_test_mat = True
		else:
			error_flags += 0b10000000 << error_bias #error256
			bpy.ops.igs_err.damned('INVOKE_DEFAULT', type='ERROR', 
				message=" Blender Mesh object '{:s}' has no material assigned.".format(ob.name))
			return error_flags, mat_data_index
		
	for face in tf_data.tessfaces:
		#check face area
		if not face_area_problems_already and not tf_data.has_custom_normals and face.area < gVertexWeldNormalThreshold:
			if not Config.u_test_mode:
				error_flags += 0b11 #Warning3
				bpy.ops.igs_err.damned('EXEC_DEFAULT', type='WARNING', 
					message=" Blender Mesh object '{:s}' face n°{:d} has a ludicrous area, there is a high risk of a hole to appear in mesh.".format(ob.name, face.index))#\n\
	#If face doesn't exist, it is generated by one of your modifiers.\n\
	#to prevent this from happening, apply your modifiers then use a normal editor and weld its normals to other faces around.\n\
	#Next occurrences of this warning will not display for this object.".format(ob.name, face.index))
			face_area_problems_already = True
		
		#check if a material is assigned to each face unless in test mode
		if face.material_index is None: #and not should_add_test_mat:
			if Config.u_test_mode:
				should_add_test_mat = True
			else:
				error_flags += 0b10000000 << error_bias #error128
				bpy.ops.igs_err.damned('INVOKE_DEFAULT', type='ERROR', 
					message=" Blender Mesh object '{:s}' has a face with no material assigned.".format(ob.name))
				return error_flags, mat_data_index
		else:
			# saves applied materials
			applied_set.add(face.material_index)
	
	bpy.data.meshes.remove(tf_data)  # @UndefinedVariable
		
	#if PROFILE_MODE:
	#	print(">>>CS: applied set: "+str(applied_set))
		
	#check if a material is present
	#11/2018 didn't check for empty mat list
	if ((not len(ob.material_slots)) or (applied_set is set())) and not should_add_test_mat:
		if Config.u_test_mode:
			should_add_test_mat = True
		else:
			error_flags += 0b100 << error_bias #error4
			bpy.ops.igs_err.damned('INVOKE_DEFAULT', type='ERROR', 
				message=" Blender Mesh object '{0}' has no material assigned.".format(ob.name))
			return error_flags, mat_data_index

	#assert applied_set or should_add_test_mat, "CheckScene: Invalid material diagnosis"

	#Review selected materials for export
	for i in range(len(ob.material_slots)):
		if i in applied_set:
			material = ob.material_slots[i].material
			
			error_flags += _checkMaterial(Config, material)
			
			print(material, error_flags)
			
			#re-raise error
			if error_bias < error_flags:
				if Config.u_test_mode:
					should_add_test_mat = True
					error_flags = 0
					continue
				else:
					return error_flags, mat_data_index
			else:
				#add material to our list of validated content
				mat_data_index.add(material.id_data)
			
	if Config.u_test_mode and (should_add_test_mat or not mat_data_index):
		if Config.u_test_mat == '':
			error_flags += 0b100 << error_bias #error4
			bpy.ops.igs_err.damned('INVOKE_DEFAULT', type='ERROR', 
				message=" Blender Mesh object '{0}' needs a valid test material".format(ob.name))
			return error_flags, mat_data_index
		
		material = bpy.data.materials[Config.u_test_mat]  # @UndefinedVariable
		error_flags += _checkMaterial(Config, material)
		#re-raise errror
		if error_bias < error_flags:
#			if PROFILE_MODE:
#				print(">>> default mat is not feeling so good...")
				
			return error_flags, mat_data_index
		mat_data_index.add(material)
	
	#super error filter
# 	if PROFILE_MODE:
# 		print(ob.name, " CS exit:",error_flags, str(mat_data_index))
# 	assert (0 < error_flags < warn_bias) or mat_data_index, "SceneCheck: No data but no errors?!!"

	
	return error_flags, mat_data_index


def checkScene(Config, objects_list):
	"""	Config, objects_list -> mat_data_index
		Checks if the objects in scene are ready for export and returns a list of materials to export"""
	mat_data_index = set()

	assert objects_list, "SceneCheck: Empty object list"

	for ob in objects_list:
		if ob.type == 'MESH':
			error_flags = 0
			error_flags, mat_data_index_i = _checkMesh(Config, ob)
			if error_bias < error_flags: #=>there are errors (flags cumulative max val < warning bias)
				print("BRIAGE: CheckScene: exiting with error code: ", error_flags)
				return None
			mat_data_index.update(mat_data_index_i)
			
			#super error filter
			#print(error_flags, str(mat_data_index_i))
			assert (0 <= error_flags <= error_bias) or not mat_data_index_i, "SceneCheck: No materials but no errors?!! for object: " + ob.name
			
# 		if ob.dupli_type not in {'NONE', 'FRAMES'}: #duplicates obj itself
# 			ob_set = None
# 			if ob.dupli_type in {'VERTS', 'FACES'}: #duplicates childs of obj
# 				ob_set = [chd for chd in ob.children if chd not in objects_list]
# 				
# 			elif ob.dupli_group : # instance a 'GROUP'
# 				ob_set = set(chd for chd in ob.dupli_group.objects if chd not in objects_list)
# 				
# 			if ob_set:
# 				new_material_data = checkScene(Config, ob_set)
# 				if new_material_data is None:
# 					return None
# 				mat_data_index.update( set(new_material_data) )
			
	#print("checkScene: exiting loop cleanly")
	
	return list(mat_data_index)