3# ##### BEGIN LICENSE BLOCK #####
#
# Copyright (C) 2018 'Juju49'(MERLE-RÉMOND Julian)
# see license notes __init__.py
#
# ##### END LICENSE BLOCK #####

#====================================================================INFO

#====================================================================IMPORTS
import bpy

from . Bl_data import (
    RESERVED_OBJECT_NAMES,
    RESERVED_OBJECT_NAMES_NB,
    RESERVED_OBJECT_NAMES_1NB)

#====================================================================GLOBALS
END_OK = 0
END_ERROR = -1
END_WARNING = -2

KEYWORD_OTHER = 0
KEYWORD_CUSTOM = 1

MAX_NAME_WITH_LOD = 31
MAX_NAME_WITHOUT_LOD = 24
SIZE_DISTANCE_DIGITS = 4

#====================================================================PRIVATE

# Return reserved name found in an object name
#MODIF2016: -->autoLOD to implement
def _has_reserved_name(name, custom_keywords):

    for reserved_name in RESERVED_OBJECT_NAMES:
        if name.find(reserved_name) >= 0:
            return reserved_name, KEYWORD_OTHER

    for reserved_name in RESERVED_OBJECT_NAMES_NB:
        i = name.find(reserved_name)
        #print(" 0>> ", name, len(name), i, len(name) - len(reserved_name) - i)
        if i != -1:
            # A keyword was found
            if len(name) - len(reserved_name) - i >= 2 and reserved_name not in RESERVED_OBJECT_NAMES_1NB:
                #print(" 1>> ", name, len(name), i, name[i + len(reserved_name)], name[i + 1 + len(reserved_name)])
                if  i >= 0 and \
                name[i + len(reserved_name)].isdigit() and name[i + 1 + len(reserved_name)].isdigit():
                    # Check for wh after bo?? (bo??wh??)
                    k = name.find('_bo')
                    if k >= 0:
                        l = name.find('wh', k + len('_bo') + 2, k + len('_bo') + 4)
                    if  k >= 0 and l >=0 and \
                    name[l + 2].isdigit() and name[l + 3].isdigit() and len(name)-k >= 9: # 1_0100_bo01wh01, 1_0100_bo01wh01G, ...
                        # bo??wh??
                        return name[k:l+4], KEYWORD_OTHER
                    else:
                        if len(name)- i == len(reserved_name) + 2:
                        # bo??, for example (then, bo01 or bo02, ... is returned)
                            return name[i:i + 2 + len(reserved_name)], KEYWORD_OTHER
                    return reserved_name, KEYWORD_OTHER
            else:
                for reserved_name in RESERVED_OBJECT_NAMES_1NB: # MAJ_1_4_1
                    i = name.find(reserved_name)
                    #print(" 3>> ", reserved_name, name, len(name), i, len(name)- i, len(reserved_name) + 1)
                    # keyword with 1 or 2 digits? (then, for example, _primarydigits_ followed by the digit is returned)
                    # Ex: 1_0032_primarydigits_3 or 1_0032_primarydigits_10 or 1_0032_primarydigits_3.001 or 1_0032_primarydigits_10.001
                    if ( ((len(name) == i + len(reserved_name) + 1) and name[i + len(reserved_name)].isdigit()) or \
                         ((len(name) > i + len(reserved_name) + 1) and name[i + len(reserved_name)].isdigit() and not name[i + len(reserved_name) + 1].isdigit()) ):
                        return name[i:i + 1 + len(reserved_name)], KEYWORD_OTHER
                    else:
                        if ( ((len(name) == i + len(reserved_name) + 2) and name[i + len(reserved_name)].isdigit() and name[i + len(reserved_name) + 1].isdigit()) or \
                             ((len(name) > i + len(reserved_name) + 2) and name[i + len(reserved_name)].isdigit() and name[i + len(reserved_name) + 1].isdigit() and not name[i + len(reserved_name) + 2].isdigit()) ):
                            return name[i:i + 2 + len(reserved_name)], KEYWORD_OTHER
                        
    for reserved_name in custom_keywords:
        if  name.find(reserved_name) >= 0:
            return reserved_name, KEYWORD_CUSTOM
                        
    return None, None

def getLOD(object_string_to_replace, Name):
    '''Get a LOD compliant name for a group: like 1_0100_name
    A LOD compliant name is 
    a digit (level), an underscore, 4 digits (visible distance), 
    and underscore and the name, 
    and the total length is <= 31 (24 for the name)'''
    
    #MODIFS2016: replace objects names if special strings found in them
    if object_string_to_replace:
        Name_old = Name
        for elem in object_string_to_replace:
            if elem.name in Name:
                Name = Name.replace(elem.name, elem.prop1)
        if Name_old is not Name:
            bpy.ops.igs_err.damned('EXEC_DEFAULT', type='INFO', message=" Object '{0}' had his name changed to '{1}'".format(Name_old, Name))
                
#MODIF2016: moved to top :
    LODlevel = '1'
    LODdist = '1000'
    name_split = Name.split('_')
    if len(name_split) >= 2:
        if name_split[0].isdigit() and name_split[1].isdigit():
        # LOD mode:
            if len(name_split[0]) is 1 and len(name_split[1]) is SIZE_DISTANCE_DIGITS:
                LODlevel = name_split[0]
                LODdist = name_split[1]
                if len(Name) > MAX_NAME_WITH_LOD:
                    NewName = Name[:MAX_NAME_WITH_LOD]
                    bpy.ops.igs_err.damned('EXEC_DEFAULT', type='WARNING', message=" Object '{:s}' processed using a truncated name at {:d} characters: '{:s}' (to comply with LOD naming rule). The converted name is used for LOD processing and may be used if the object is head of group.".format(Name, MAX_NAME_WITH_LOD, NewName))
                    return int(LODlevel), int(LODdist), NewName
                else:
                    return int(LODlevel), int(LODdist), Name
            else:
                if len(name_split[0]) is 1: # LODlevel
                    if len(name_split[1]) >= SIZE_DISTANCE_DIGITS: # LODdist
                    # Truncate
                        LODlevel = name_split[0]
                        LODdist = name_split[1]
                        NewName = "_".join([LODlevel, LODdist[:SIZE_DISTANCE_DIGITS], name_split[2]])
                        bpy.ops.igs_err.damned('EXEC_DEFAULT', type='WARNING', message=" Object '{:s}' processed as '{:s}' (to comply with LOD naming rule). The converted name is used for LOD processing and may be used if the object is head of group.".format(Name, NewName[:MAX_NAME_WITH_LOD]))
                        return int(LODlevel), int(LODdist[:SIZE_DISTANCE_DIGITS]), NewName[:MAX_NAME_WITH_LOD]
                    else:
                    # Pad
                        LODlevel = name_split[0]
                        LODdist = name_split[1]
                        NewName = "_".join([LODlevel, LODdist.ljust(SIZE_DISTANCE_DIGITS,'0'), name_split[2]])
                        bpy.ops.igs_err.damned('EXEC_DEFAULT', type='WARNING', message=" Object '{:s}' processed as '{:s}' (to comply with LOD naming rule). The converted name is used for LOD processing and may be used if the object is head of group.".format(Name, NewName[:MAX_NAME_WITH_LOD]))
                        return int(LODlevel), int(LODdist.ljust(SIZE_DISTANCE_DIGITS,'0')), NewName[:MAX_NAME_WITH_LOD]
                    
    #default alternative:
    NewName = "_".join([LODlevel, LODdist, Name[:MAX_NAME_WITHOUT_LOD]])
    bpy.ops.igs_err.damned('EXEC_DEFAULT', type='WARNING', message=" Object '{:s}' processed as '{:s}' (to comply with LOD naming rule). The converted name is used for LOD processing and may be used if the object is head of group.".format(Name, NewName))
    return int(LODlevel), int(LODdist), NewName # (LODlevel + '_' + LODdist + '_' + Name)

class group_wrapper(object):
    '''Class to group objects along criteria in order to merge them into a single object'''

    __slots__ = ("LODlevel", "LODdist", 
                "keyword", "parent_group", 
                "name", "objects_list", 
                "child_groups_list", 
                "IGinstance_id", "IGinstance",
                "type_o")

    def __init__(self, LODlevel=1, LODdist=0, keyword=None, parent_group=None, name="", type_o='MSH'):
        self.LODlevel = int(LODlevel)
        self.LODdist = int(LODdist)
        self.keyword = keyword
        self.parent_group = parent_group
        self.name = name
        self.type_o = type_o #str in {'MSH', 'SPT'} (Mesh, snap point, armature)
#         self.duplicator = None
#         self.dupli_flip_matrix = False
        self.objects_list = []
        self.child_groups_list = []
        self.IGinstance_id = 0 # Id of the related IGinstance
        self.IGinstance = None # Related IGinstance

    def __eq__(self, other):
        if self.type_o != other.type_o:
            return False
        
        if (self.LODlevel is not other.LODlevel) or (self.LODdist is not other.LODdist):
            return False
    
        # LODlevel == LODlevel_parent and LODdist != LODdist_parent and parent_object_keyword != None (example: 1_0100_Parent wwith 2 children 1_0030_Child1 and |_1_0030_Child2, then 1_0030_Child* are merged)
        if (other.LODlevel > 1) or (other.LODdist is not self.LODdist): # MAJ_1_4_1 / 1.4.4
            if other.parent_group is not self.parent_group:
                # They must be siblings
                return False
            #else:
            #    print(" >> (obj_parent == current_group.objects_list[0].parent) ", obj_parent)
    
        if self.keyword is not other.keyword:
            return False
        
        return True

#MODIFS2016: -->LOD level modular joining
# def same_group(hierarchy_processing, current_group, new_LODlevel, new_LODdist, LODdist_parent, new_keyword, keyword_type, obj_parent):
#     if not len(current_group.objects_list):
#         return False
#     if (current_group.LODlevel is not new_LODlevel) or (current_group.LODdist is not new_LODdist):
#         return False
# 
#     # LODlevel == LODlevel_parent and LODdist != LODdist_parent and parent_object_keyword != None (example: 1_0100_Parent wwith 2 children 1_0030_Child1 and |_1_0030_Child2, then 1_0030_Child* are merged)
#     if (new_LODlevel > 1) or (new_LODdist is not LODdist_parent): # MAJ_1_4_1 / 1.4.4
#         if obj_parent is not current_group.objects_list[0].parent:
#             # They must be from the same parent
#             return False
#         #else:
#         #    print(" >> (obj_parent == current_group.objects_list[0].parent) ", obj_parent)
# 
#     if current_group.keyword is not new_keyword:
#         return False
# 
#     if keyword_type == KEYWORD_CUSTOM:
#         return True
#     
#     if not hierarchy_processing:
#         return False
#     return True

def _register_group(groups_list, new_group):
    if new_group.parent_group:
        new_group.parent_group.child_groups_list.append(new_group) # Store child group wrapper reference in parent group wrapper
        
    groups_list.append(new_group)
    
    if new_group.keyword:
        new_group.parent_group.keyword = new_group.keyword

# def _add_duplis_to_group(Config, obj, parent_group, groups_list, processed_objects_list):
#     if obj.dupli_type == 'NONE':
#         return #we care about duplis, others will just crash our stuff!
#     
#     obj.dupli_list_create(Config.context.scene, 'PREVIEW')
#     
#     local_dupli_obj_list = list(obj.dupli_list)
#     local_dupli_processed_obj_list = []
#     local_groups_list = []
# 
#     #resolve children if dupli_gp and compute some name change, i.e. for duplicating bogies easely
#     if obj.dupli_type == 'GROUP' and obj.dupli_group:
#         #compute prefixes and suffixes
#         prefix = ""
#         suffix = ""
#         if obj.name:
#             offset_to_get_name = 0
#             if parent_group and (obj in parent_group.objects_list) and (parent_group.type_o == 'MSH'):
#                 offset_to_get_name = 7 #size of "1_1000_" at the begining of msh obj
#                 
#             if obj.name[-1] == '*': #star at the end
#                 suffix = obj.name[offset_to_get_name:-1]
#                 
#             else: #parent_group.name[offset_to_get_name] == '*': #star at the beginning #just do it to avoid confusion
#                 prefix = obj.name[offset_to_get_name:]
#                 
#         #list all objects used by duplis
#         dupli_group_match_list = list(obj.dupli_group.objects)
#         
#         for curr_dupli in local_dupli_obj_list:
#             #add dupli to gp list
#             _add_to_group(Config, [], curr_dupli.object, parent_group, local_groups_list, [])
#             
#             gp = local_groups_list[-1]
#             
#             #replace real ob by a dupli to handle it correctly later on without having to build a new function
#             gp.objects_list[0] = curr_dupli
# 
#             #store its id for ia export inter-frame matching
#             gp.duplicator = obj
#             
#             #add to processes obj list
#             local_dupli_processed_obj_list.append(curr_dupli.object)
#             
#             #add prefixes and suffixes
#             if prefix or suffix:
#                 group_name = gp.name
#                 if gp.type_o == 'MSH':
#                     group_name = group_name[:7] + prefix + group_name[7:] + suffix
#                 elif gp.type_o == 'SPT':
#                     group_name = group_name[:4] + prefix + group_name[4:] + suffix
#                     
#                 gp.name = group_name
#             
#             #link parents and their children
#             dupli_parent = gp.objects_list[0].object.parent
#             if (dupli_parent is not None) and (dupli_parent in dupli_group_match_list):
#                     ob_to_find = dupli_group_match_list[dupli_group_match_list.index(dupli_parent)]
#                     for parent_gp in local_groups_list:
#                         find_ob_in_dupli = set(ob.object for ob in parent_gp.objects_list)
#                         if ob_to_find in find_ob_in_dupli:
#                             if gp.parent_group:
#                                 #print("...removed from: '{}' ".format(gp.parent_group.name), end="")
#                                 gp.parent_group.child_groups_list.remove(gp)
#                             gp.parent_group = parent_gp
#                             if gp.parent_group.duplicator:
#                                 gp.dupli_flip_matrix = not parent_gp.dupli_flip_matrix
#                             parent_gp.child_groups_list.append(gp)
#                             #print("added child to '{}'.".format(parent_gp.name))
#                             break
#                 
#     
#     elif parent_group: #only valid if duplicator is valid group
#         if obj.dupli_type == 'FRAMES': #duplicate itself
#             parent_group.objects_list.extend(local_dupli_obj_list)
#             parent_group.duplicator = obj
#             local_dupli_processed_obj_list.extend([parent_group.objects_list[0]*len(local_dupli_obj_list)])
#     
#         else: #obj.dupli_type in {'VERTS', 'FACES'} #duplicate children
#             child_group_list = groups_list[groups_list.index(parent_group)-1:]
#             max_duplis_for_an_object = min(len(local_dupli_obj_list) // len(child_group_list), 0)
#             #we must not forget that these child objects can be merged in another group
#             
#             for child_gp in child_group_list:
#                 
#                 if (child_gp.type_o == 'MSH' and child_gp.name[0] == '1' and (child_gp.objects_list[0].animation_data or child_gp.objects_list[0].constraints)) \
#                 or child_gp.type_o != 'MSH':
#                     #we do not merge these duplis together because they have animation
#                     #only first lod because there is no way to figure out new relationships between objects
#                     num_dupli_found = 0
#                     for curr_dupli in local_dupli_obj_list:
#                         if curr_dupli.object is child_gp.objects_list[0]:
#                             #add dupli to gp list
#                             _add_to_group(Config, [], curr_dupli.object, parent_group, local_groups_list, [])
#                             
#                             gp = local_groups_list[-1]
#                             #replace real ob by a dupli to handle it correctly later on without having to build a new function
#                             gp.objects_list[0] = curr_dupli
#                             #store its id for ia export inter-frame matching
#                             gp.duplicator = obj
#                             
#                             #add to processes obj list
#                             local_dupli_processed_obj_list.append(curr_dupli.object)
#                             
#                             #add suffix
#                             gp.name += str(curr_dupli.random_id)
#                             num_dupli_found += 1
#                         
#                         if num_dupli_found >= max_duplis_for_an_object:
#                             break #there cannot be more duplis of this object in the list
#                 else:
#                     #we merge these together to eco performances
#                     for curr_dupli in local_dupli_obj_list: 
#                         #allows to have a dupli in more than one group to
#                         #be compatible with LOD auto merging algorithm
#                         if curr_dupli.object in child_gp.objects_list:
#                             child_gp.objects_list.append(curr_dupli)
#                             child_gp.duplicator = obj
#                             local_dupli_processed_obj_list.append(curr_dupli.object)
#                         
# 
#     
#     processed_objects_list.extend(local_dupli_processed_obj_list)
#     groups_list.extend(local_groups_list)
    


#MODIF2016: add snap points :
def _add_to_group(Config, mObjects_list, obj, parent_group, groups_list, processed_objects_list):
    """Sort objects in groups according to LOD, keyword,... : group_wrapper objects are created with parent group wrapper and a list of children group_wrapper."""
    #print(" add_group name={:s} // parent_object_keyword={:s}".format(obj.name, parent_object_keyword))
    hierarchy_processing = Config.hierarchy_processing
    custom_keywords = [kword.name for kword in Config.KeywordsListItem if kword.prop1]
    keyword, keyword_type = None, None
    
    if obj in processed_objects_list:
            return
        
    if obj.type == 'EMPTY' and not len(obj.children):
        #MODIF: snap points :
        name_split = obj.name.split('_')
        if ("#s" in name_split[0]) and len(name_split[0]) is 3:
            obj_group = group_wrapper(0, 0, keyword, parent_group, obj.name, 'SPT')
            obj_group.objects_list.append(obj)
            
            _register_group(groups_list, obj_group)
            
            
            bpy.ops.igs_err.damned('EXEC_DEFAULT',type='INFO', message=" object '{0}' has been processed as Snap Point".format(obj.name))
    
    
    
    elif obj.type == 'MESH': #MODIFS2016: auto nodes
        obj_group = None
        LODlevel, LODdist, group_name = getLOD(Config.object_string_to_replace, obj.name) # MAJ3
        new_gp = group_wrapper(LODlevel, LODdist, keyword, parent_group, group_name, 'MSH')
        
        if hierarchy_processing and not (obj.animation_data or obj.constraints):
            
            if parent_group is not None and LODlevel == parent_group.LODlevel and LODdist == parent_group.LODdist:
                #
                obj_group = parent_group

            else:
                keyword, keyword_type = _has_reserved_name(group_name, custom_keywords) # MAJ3 / 1.4.2
                
                if (keyword is None or keyword_type == KEYWORD_CUSTOM) and len(obj.children) == 0:
                    # LODlevel == LODlevel_parent and LODdist != LODdist_parent and parent_object_keyword != None (example: 1_0100_Parent with 2 children 1_0030_Child1 and |_1_0030_Child2, then 1_0030_Child* are merged)
                    if (keyword_type == KEYWORD_CUSTOM) and \
                    (parent_group.keyword == None or 
                    keyword_type == KEYWORD_CUSTOM or 
                        (LODlevel == parent_group.LODlevel and 
                        LODdist != parent_group.LODdist and 
                        parent_group.keyword != None)
                    ): # 1.4.4
                        
                        for current_group in groups_list:
                            if current_group == new_gp:
                                obj_group = current_group
                                break
                        #else:
                            #nothing found to add itself to
                        #    pass
                            
        if obj_group is None:
        # Create a new group and store it to the common list
            obj_group = new_gp
            
            _register_group(groups_list, obj_group)
            
            parent_group = obj_group
        #
        #add object to selected group
        obj_group.objects_list.append(obj)
    
    #elif obj.type == 'ARMATURE':
    #    obj_group = group_wrapper(0, 0, None, parent_group, obj.name, 'ARM')
    #    _register_group(groups_list, obj_group)
        
    else:
        #print(" not mesh or empty: {:s}".format(obj.name))
        #parent_group = None # Example: no parent for children of LATTICE or ARMATURE
        pass
        
    processed_objects_list.append(obj)
    #bpy.ops.igs_err.damned('EXEC_DEFAULT',type='INFO', message=" object '{}' has been processed in a group".format(obj.name))
    
    if not (parent_group and parent_group.type_o == 'SPT') and (obj in mObjects_list): #do not search through children for snap points and duplis
        #to avoid searching through all groups and just cut away from list groups
        #which are not involved for sure. To do this, we save postion of parent group in list and
        # all groups after this and before duplis computation are sure to be its children.
            
        for obj_children in obj.children:
            #print(" child {:s} parent_object_keyword={:s} (parent {:s})".format(obj_children.name, parent_object_keyword, obj.name))
            #if not visible_children or (visible_children and obj_children.is_visible(scene)): # MAJ 1.4.2
            if obj_children in mObjects_list:
                _add_to_group(Config, mObjects_list, obj_children, parent_group, groups_list, processed_objects_list)
    
        #compute duplis here to be able to handle fusion of dupli 'VERTS', 'FACES' and 'FRAMES'
        #which add there 3D to original parent's respective children group to avoid namming issues with ia export
        #_add_duplis_to_group(Config, obj, parent_group, groups_list, processed_objects_list)

def _group_wrapper_dump(groups_list):
    print("\n ------------------ Groups list -----------------\n+--- {:d} groups ---\n|".format(len(groups_list)))
    def recursive_dump(gp,lvl):
        print("|  "*lvl+"+--> {:s} (kw: {:s})".format(gp.name, gp.keyword or "None"))
        print("|  "*lvl+"|         type: {:s}".format(gp.type_o))
        if len(gp.objects_list):
            print("|  "*lvl+"|  [ included objects:                ]")
        for ob in gp.objects_list:
            if type(ob) is bpy.types.DupliObject:#process duplis @UndefinedVariable
                print("|  "*lvl+"|  [ {:<32} ](dupli)".format(ob.object.name))
            else:
                print("|  "*lvl+"|  [ {:<32} ]".format(ob.name))
            
        for chd in gp.child_groups_list:
            print("|  "*(lvl+2))
            recursive_dump(chd, lvl+1)
        print("|  "*(lvl+1))
        
    
    for grp in groups_list:
        if grp.parent_group is None:
            recursive_dump(grp, 0)
            print("|")

#====================================================================PUBLIC

def make_groups(Config, objects_list, dump_grps=True):
    """"Sort objects in groups"""
    
    groups_list = []
    processed_objects_list = []
    
    for obj in objects_list:
        if not (obj.parent in objects_list): # don't process a child before its parent
            _add_to_group(Config, objects_list, obj, None, groups_list, processed_objects_list)
    
    assert len(groups_list) > 0, "No Groups found!"
    
    if dump_grps:
        _group_wrapper_dump(groups_list)
        
    return groups_list

