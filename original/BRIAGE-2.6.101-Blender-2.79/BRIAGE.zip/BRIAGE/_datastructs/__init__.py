﻿# ##### BEGIN LICENSE BLOCK #####
#
# Copyright (C) 2016  'DOM107', 'Juju49'(MERLE-RÉMOND Julian)
# see license notes __init__.py
#
# ##### END LICENSE BLOCK #####

#====================================================================INFO
__all__ = ["IAF", "IGF"]
