﻿# ##### BEGIN LICENSE BLOCK #####
#
# Blender IGS exporter. Exports data from Blender software to Kuju's IG/IA
# format files.
# Copyright (C) 2023  'Juju49'(MERLE-RÉMOND Julian), 'DOM107'
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights to
# use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies
# of the Software, and to permit persons to whom the Software is furnished to do so,
# subject to the following conditions:
#   -The above copyright notice and this permission notice shall be included 
#    in all copies or substantial portions of the Software.
#	-The origin of the Software must be easily identifiable from its
#	 download description page.
#	-User-modified versions of the Software require to be marked as clearly
#	 as possible that they are different from the original version.
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
# THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
# THE SOFTWARE.
#
# Contact:
#  e-mail: 			julian.merle-remond@devmares.net
#  mailing address: MERLE-RÉMOND Julian, 
#					27 rue de l'Abbé Grégoire
#					75006, Paris
#					FRANCE
#	
# ##### END LICENSE BLOCK #####

#====================================================================INFO
bl_info = {
	"name": "BRIAGE - TS Exporter(.igs, .ia)",
	"author": "Juju49, dom107",
	"version": (2, 6, "101"),
	"blender": (2, 79, 0),
	"location": "Properties > Scene > IA/IGS export options",
	"description": "Export IGS/IA Model Format (.igs) for DTG Train Simulator Classic",
	"warning": "",
	"tracker_url": "https://discord.gg/7wuMyjy",
	"support": 'COMMUNITY',
	"category": "Import-Export"}

PCKG_VERSION = 'BRIAGE V' + '.'.join(str(i) for i in bl_info['version'])

__all__ = ["Utilityfcts", "IGSE", " IAE", "Bl_data", "SceneCheck"]

#====================================================================CHECK PyVERSION
import sys
if sys.version_info[:2] < (3, 5):
	raise "must use python 3.7 (Blender 2.79.7)"
#elif sys.version_info[:2] > (3, 5):
#	print("BRIAGE: Should use python 3.5 (Blender 2.79b) - high risk of data corruption")

#====================================================================RELOAD MODULES
from . import Utilityfcts
import os.path
import bpy
BINARY_PATH = Utilityfcts.get_binpath()
Utilityfcts.setup_addon_modules(BINARY_PATH, __name__, "bpy" in locals())

#====================================================================REGISTER/UNREGISTER
from . import Bl_data
import bpy.utils
def register():
	bpy.utils.register_module(__name__)
	Bl_data.register()
	
	Utilityfcts.print_pr(1)
	
def unregister():
	bpy.utils.unregister_module(__name__)
	Bl_data.unregister()